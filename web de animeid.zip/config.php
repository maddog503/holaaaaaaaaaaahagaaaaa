<?php
//-> CONFIGURACION DE LA BASE DE DATOS
//->Archivo creado con 'SERBice Installer for Movie Script'
//->Fecha de creacion Tue, 29 Nov 2011 12:02:21 -0600
define('db_host', 'localhost');	// SERVIDOR
define('db_name', 'animevis_pruebas');	// NOMBRE DE LA BASE DE DATOS
define('db_user', 'animevis_prueba');	// USUARIO DE LA BASE DE DATOS
define('db_pass', 'palomos1');	// CONTRASEÑA
define('db_prefix', 'ms_'); //PREFIJO DE TABLAS
?>