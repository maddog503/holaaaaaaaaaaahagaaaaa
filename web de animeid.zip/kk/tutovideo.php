<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>TUTORIAL PARA VER LOS VIDEOS EN HD</title>
</head>
<p align="left"><font color="#008000"><b>HOLA AMIGOS ESTE VIDEO LE ESE�ARA COMO 
VER </b></font></p>
<p align="left"><font color="#008000"><b>LOS VIDEO HD O SEGUNDA OPCION&nbsp;&nbsp; 
MIENTRAS</b></font></p>
<p align="left"><font color="#008000"><b>CAMBIAMOS LA FORMA DE VERLAS EN OPCION 
1</b></font></p>
<p align="left"><b><font size="5" color="#FF0000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

TUTORIAL&nbsp; </font><font size="5">&nbsp;</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</b></p>
<p>&nbsp;<iframe width="425" height="349" src="http://www.youtube.com/embed/OXz0PUyOTAg" frameborder="0" allowfullscreen></iframe>

</p>
<p><b><font size="2">HAY ALGUNOS VIDEOS QUE NO FUNCIONA HAGANOS SABER POR FACE</font></b></p>
<p>&nbsp;</p>


</html>