<?php
if ($_GET['randomId'] != "xgcs8kA_cNa8CIxC6Nb_xk2EUTYR_5WQhJ61sKxmtqvqhjjApTC9CEnM6Bv4dujA") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
