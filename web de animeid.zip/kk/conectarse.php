<html>
<head>
   <title>Ejemplo de PHP</title>
</head>
<body>
<?php
function Conectarse(){
   if (!($link=mysql_connect("localhost","animevis_anime","D,(1!xT9O+JrSOMrNN"))){
      echo "Error conectando a la base de datos.";
      exit();
   }
   if (!mysql_select_db("hentaico_ruxel",$link)){
      echo "Error seleccionando la base de datos.";
      exit();
   }
   return $link;
}
Conectarse();
echo "Conexi�n con la base de datos conseguida.<br>";
?>
</body>
</html>