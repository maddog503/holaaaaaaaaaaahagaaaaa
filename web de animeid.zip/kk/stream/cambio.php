<?
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
include("../config.php");
include("../inc/class/c.db.php");
include("../inc/class/c.core.php");
$msdb =& msMySQL::getInstance();
$msCore	=& msCore::getInstance();
$msConfig=$msCore->settings;
$msTitulo=$msCore->settings['datos']['w_titulo'];
$msURL=$msConfig['datos']['w_url'];
if($_GET['get'] =='opera'){ 
?>
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$msTitulo?> | Reproducir video</title>
<style type="text/css">
-->
body{margin:0;padding:0;font-family:"Lucida Grande",Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:normal;color:#FFF;background:url(img/fondo.gif) repeat-x;background-color:#111;}a{color:#4fa4e5;text-decoration:none;}a:hover{text-decoration:underline;}a:focus{outline:none;}
li.pregunta{margin-top:5px;color:#999;font-size:14px;font-family:Helvetica,"Lucida Grande",Arial,sans-serif;border-bottom:1px solid #999;}
-->
</style>
</head>
<body>
Este tutorial te ayudará a instalar el plugin necesario para ver los videos online en Opera.
                <p><i>Es importante destacar que este tutorial es compatible con Opera 9 o superior. Si tienes una versión anterior, asegúrate de descargar la última desde <a href="http://www.opera.com/" target="_blank">aquí</a>.</i></p>
                <ul id="preguntasfrecuentes">
        		<li class="pregunta">1. Habilita archivos JavaScript de usuario</li>
                <li>Para habilitar los archivos JavaScript de usuario en Opera, debes ir a Menú &gt; Configuración &gt; Opciones &gt; Avanzado &gt; Contenido &gt; Opciones JavaScript. Allí, en el último campo, selecciona un directorio donde guardarás los códigos JavaScript (por ej, crea una carpeta en Mis Documentos, llamada Codigos JavaScript) y haz click en OK.</li>

                <li class="pregunta">2. Descarga el script <?=$msTitulo?></li>
                <li>Descarga el script <?=$msTitulo?> desde <a href="<?=$msURL?>/stream/tds/script.user.js">aquí</a> (Click derecho, Guardar como...). Guardalo en la carpeta que creaste en el paso 1, para códigos JavaScript.</li>
                <li class="pregunta">3. Reinicia tu navegador y disfruta</li>
                <li>Ya estás listo para reproducir videos en <?=$msTitulo?>. Simplemente asegúrate de reiniciar (cerrar y volver a abrir) tu navegador para que los cambios tengan efecto.</li>
</body>
</html>

<?
exit();}

if($_GET['get'] =='ie'){ 
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$msTitulo?> | Reproducir video</title>
<style type="text/css">
-->
body{margin:0;padding:0;font-family:"Lucida Grande",Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:normal;color:#FFF;background:url(img/fondo.gif) repeat-x;background-color:#111;}a{color:#4fa4e5;text-decoration:none;}a:hover{text-decoration:underline;}a:focus{outline:none;}
li.pregunta{margin-top:5px;color:#999;font-size:14px;font-family:Helvetica,"Lucida Grande",Arial,sans-serif;border-bottom:1px solid #999;}
-->
</style>
</head>
<body>
Este tutorial te ayudará a instalar el plugin necesario para ver los videos online en Internet Explorer.
                <p><i>Si tienes problemas con tu navegador, asegúrate de actualizarlo a la última version (Internet Explorer 8). Si tienes una versión anterior, asegúrate de descargar la última desde <a href="http://www.microsoft.com/spain/windows/internet-explorer/" target="_blank">aquí</a>.</i></p>
                <ul id="preguntasfrecuentes">
        		<li class="pregunta">1. Descarga Trixie para Internet Explorer</li>
                <li>Debes instalar Trixie para poder correr el script <?=$msTitulo?> (para reproducir videos online en <?=$msTitulo?>). Descárgalo de <a href="http://www.bhelpuri.net/Trixie/TrixieSetup.msi">aquí</a>.</li>

                <li class="pregunta">2. Ejecuta e instala el programa descargado</li>
                <li>Una vez termines de descargar Trixie, ejecuta el archivo e instala Trixie en tu PC.</li>
                <li class="pregunta">3. Descarga e instala el script <?=$msTitulo?></li>
                <li>Descarga el script Cuevana Stream desde <a href="<?=$msURL?>/stream/tds/script.user.js">aquí</a> (Click derecho, Guardar como). Debes guardar el archivo en el directorio Scripts de Trixie ubicado en C:/Archivos de programa/Bhelpuri/Trixie/Scripts.</li>
                <li class="pregunta">4. Reinicia Internet Explorer y activa el plugin</li>

                <li>Cierra y vuelve a abrir Internet Explorer. Luego, ve a Herramientas &gt; Trixie Options. Aparecerá una lista con tics, asegúrate que <?=$msTitulo?> tenga un tic (los demás no son importantes, si quieres desmárcalos todos). Haz click en OK.</li>
                <p>Ya estás listo para reproducir videos en <?=$msTitulo?>. Si

 no notas cambios, asegúrate de reiniciar el explorador una última vez.</p>
 
</body>
</html>
<?

exit();}
if($_GET['get']=='plugin'){
	?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$msTitulo?> | Reproducir video</title>
<link rel="stylesheet" type="text/css" href="css/getplugin2.css" />
<script type="text/javascript">
var isFirefox = navigator.userAgent.indexOf('Firefox') >= 0;
function install (e) {
	if (!isFirefox) { return; }

	var params = {
		 "<?=$msTitulo?> Stream": {
			URL: e.currentTarget.href,
			toString: function () { return this.URL; }
		}
	};

	InstallTrigger.install(params);
	return false;
}
</script>
</head>

<body>

<div id="tabblock">
<div id="block_1">
    <h1>Plugin de <?=$msTitulo?> no instalado en el navegador</h1>
    <p>Debes instalar una extensión en tu navegador para que <?=$msTitulo?> pueda cargar los videos. Elige tu navegador para descargar la extensión para éste:</p>
    
    <div class="op_plugin" style="margin-bottom:15px;" id="op_plugin1">
    <div class="tit">Recomendados</div>
    <a href="plugins/chrome.crx"><img src="img/browsers/chrome.png" width="60" height="60" border="0" /></a> <a href="plugins/firefox.xpi"  onclick="return install(event);"><img src="img/browsers/firefox.png" width="60" height="60" border="0" /></a> 

    </div>
    
    <div class="op_plugin" id="op_plugin2">
    <div class="tit">Otros</div>
    <a href="?get=ie" target="_parent" onclick="window.open(this.href,'','width=500,height=520');return false;"><img src="img/browsers/ie.png" width="60" height="60" border="0" /></a>  <a href="?get=opera" onclick="window.open(this.href,'','width=500,height=520');return false;" target="_parent"><img src="img/browsers/opera.png" width="60" height="60" border="0" /></a>   
    </div>
    
   

</div>
</div>

<!--
<div id="popup">
<div class="cerrar"><a href="#" onclick="body.removeChild(document.getElementById('popup'));return false"></a></div>
</div>
-->
</body>
</html>
    
    <?
	exit();
	}
	if($_GET['get']=="list"){
if(!is_numeric($_GET['id'])){exit("BITCH!!!!!!!!!!!!!!");}
$result = $msdb->query("SELECT * FROM ms_stream WHERE id = '".$_GET['id']."' ");
if(!$result){die('OTRA BITCH!!!!');}
$row = mysql_fetch_array($result, MYSQL_ASSOC);
$toditit=array($row['mega'],$row['bitshare'],$row['ffactory'],$row['mfire'],$row['hotfile']);
		?>
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$msTitulo?> | Reproducir video</title>
<link rel="stylesheet" type="text/css" href="css/getplugin.css" />
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript">
function goSource(host) {
	var e = $("#error");
	if ($.browser.msie && host!='megaupload' && host!='bitshare' && host!='filefactory') {
		e.html("Lo sentimos, esta fuente no está disponible para tu navegador. Te recomendamos usar Google Chrome, Firefox o Safari.");
	} else {
		e.html("Cargando fuente seleccionada...");
		$.ajax({
			url: 'source_get.php',
			type: 'POST',
			data: {host:host,id:<?=$_GET['id']?>,vars:"&id=<?=$_GET['id']?>&sub=<?=$_GET['sub']?>&sub_pre=ES"},
			success: function(u) {
				e.html("Fuente cargada con éxito. Redirigiendo...");
				window.location = u;
			},
			error: function() {
				e.html("Ha ocurrido un error. Por favor, intenta nuevamente.");
			}
		});
	}
}
</script>
</head>

<div style="position:absolute;width:640px;height:360px;background-color:#000;text-align:center;">

<div style="padding-top:40px;">
<h2>Elige una fuente</h2>
<div style="margin-bottom:20px">La fuente determina desde cual servidor se va a reproducir el video.</div>
<div id="sources">
<ul>
<?

if($row['mega'] != "" || $row['mega'] != NULL){
	?>
    <li style="width:33.333333333333%;margin-top:10px;"><a href="#" id="f_0"><img src="img/servers/megaupload.jpg" height="130" width="130" border="0" /></a></li>
	<script type="text/javascript">
	$("#f_0").click(function() {
		goSource('megaupload');
		return false;
	});
	</script>
    
    <?
	}
if($row['bitshare'] != "" || $row['bitshare'] != NULL){
		?>
    
    <li style="width:33.333333333333%;margin-top:10px;"><a href="#" id="f_1"><img src="img/servers/bitshare.jpg" height="130" width="130" border="0" /></a></li>
	<script type="text/javascript">
	$("#f_1").click(function() {
		goSource('bitshare');
		return false;
	});
	</script>
    <?
	}
if($row['ffactory'] != "" || $row['ffactory'] != NULL){
		?>
    <li style="width:33.333333333333%;margin-top:10px;"><a href="#" id="f_2"><img src="img/servers/filefactory.jpg" height="130" width="130" border="0" /></a></li>
	<script type="text/javascript">
	$("#f_2").click(function() {
		goSource('filefactory');
		return false;
	});
	</script>
    
    <?
	}
if($row['mfire'] != "" || $row['mfire'] != NULL){
		?>
    <li style="width:33.333333333333%;margin-top:10px;"><a href="#" id="f_3"><img src="img/servers/mediafire.jpg" height="130" width="130" border="0" /></a></li>
	<script type="text/javascript">
	$("#f_3").click(function() {
		goSource('mediafire');
		return false;
	});
	</script>
    
    <?
	}
if($row['hotfile'] != "" || $row['hotfile'] != NULL){
		?>
    <li style="width:33.333333333333%;margin-top:10px;"><a href="#" id="f_4"><img src="img/servers/hotfile.jpg" height="130" width="130" border="0" /></a></li>
	<script type="text/javascript">
	$("#f_4").click(function() {
		goSource('hotfile');
		return false;
	});
	</script>
    
    <?
	}
	mysql_free_result($result);
?>


<div style="clear:left"></div>
</ul>
</div>
<div id="error"></div>

</div>
</div>
</body>
</html>
		<?
		exit();
		}