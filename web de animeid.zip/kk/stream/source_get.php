<?
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
if($_POST){
	if(!is_numeric($_POST['id'])){exit('BIIIIIIITCH!');}
	include("key.php");
	include("../config.php");
	include("../inc/class/c.db.php");
	$msdb =& msMySQL::getInstance();
	$unik_key= KEY;//LLAVE UNICA
	$result = $msdb->query("SELECT * FROM ms_stream WHERE id = '".$_POST['id']."' ");
	if(!$result){die('OTRA BITCH!!!!');}
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	///MEGAUPLOAD INICIO
if($_POST['host']=="megaupload"){
	echo($row['mega'].'&key='.$unik_key.$_POST['vars']);	
	}
if($_POST['host']=="bitshare"){
	echo($row['bitshare'].'&key='.$unik_key.$_POST['vars']);	
	}
if($_POST['host']=="filefactory"){
	echo($row['ffactory'].'?key='.$unik_key.$_POST['vars']);	
	}
if($_POST['host']=="mediafire"){
	echo($row['mfire'].'&key='.$unik_key.$_POST['vars']);	
	}
if($_POST['host']=="hotfile"){
	echo($row['hotfile'].'&key='.$unik_key.$_POST['vars']);	
	}

	///MEGAUPLOAD FIN
	
		mysql_free_result($result);
	}
?>