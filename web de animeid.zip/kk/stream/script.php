<?php
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
include("../config.php");
include("../inc/class/c.db.php");
include("../inc/class/c.core.php");
$msdb =& msMySQL::getInstance();
$msCore	=& msCore::getInstance();
$msConfig=$msCore->settings;
$msTitulo=$msCore->settings['datos']['w_titulo'];
$msURL=$msConfig['datos']['w_url'];
if($_GET['tipo']=="bitshare"){
	header('Content-type: text/javascript');
?>
var but=document.getElementById("activdownloadbutton");
var box=document.createElement("div");
box.style.backgroundColor="#000000";
box.style.color="#FFFFFF";
box.style.width="100%";
box.style.height="100%";
box.style.position="absolute";
box.style.top="0";
box.style.left="0";
box.style.textAlign="center";
box.style.fontSize="12px";
box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
box.style.zIndex="10000";
document.body.appendChild(box);
var logo=document.createElement("div");
logo.style.paddingTop="50px";
logo.align='center';
box.appendChild(logo);
logo.innerHTML="<center><a style='float:left;height:78px;width:267px;margin:5px;overflow:hidden;'  href='<?=$msURL?>/'><img src='<?=$msURL?>/Temas/default/img/bg.png' alt='<?=$msTitulo?>' /></a></center>";
var box2=document.createElement("div");
box2.style.paddingTop="50px";
box.appendChild(box2);
document.body.style.overflow="hidden";
if(but){box2.appendChild(but);
but.innerHTML="Click aquí para cargar el video";
but.className='';
but.style.background="#333";
but.style.fontWeight="bold";
but.style.padding="3px 7px";
but.style.color="#FFFFFF";
but.style.textDecoration="none";
but.style.display="inline";
if(but.addEventListener){
	but.addEventListener("click",clickBut,false);
	}else{
		but.attachEvent("onclick",clickBut);
		}
		}else{
			var pag=document.body.innerHTML;
			if(pag.match(/Sorry, you cant download more then 1 files at time/i)){box2.innerHTML="Ya estás descargando un archivo desde Bitshare. <br />No puedes cargar más de 1 archivo en simultáneo sin una cuenta premium en Bitshare.com (<a href='http://bitshare.com/myupgrade.html' target='_blank'>comprar una cuenta premium en Bitshare</a>).";
			}else if(pag.match(/File not available/i)){
				box2.innerHTML="El archivo ha sido eliminado de Bitshare.";
				}else if(
				document.getElementById("dlbutton")){
					var b=document.getElementById("dlbutton").getElementsByTagName("a")[0];
					b.innerHTML="Click aquí para cargar el video";
					b.className='';
					b.style.background="#333";
					b.style.fontWeight="bold";
					b.style.padding="3px 7px";
					b.style.color="#FFFFFF";
					b.style.textDecoration="none";
					b.style.display="inline";
					box2.appendChild(b);getFinalLink();}
					}
function clickBut(e){
	if(but.removeEventListener){
		but.removeEventListener("click",clickBut,false);
		}else{
			but.detachEvent("onclick",clickBut);
			}
box2.innerHTML="Cargando...";
setTimeout("loadCaptcha()",200);
}

function loadCaptcha(){
	if(document.getElementById("counter")){
		var m=parseInt(document.getElementById("counter").innerHTML);
		if(m>0){
			box2.innerHTML="Por favor, espera "+m+" segundos";
			}else{
				box2.innerHTML="Cargando...";setTimeout("getLink()",500);return;}
				}
setTimeout("loadCaptcha()",500);}
function getCaptcha(){
	var form=document.getElementById("captcha");
	if(form){
		box2.innerHTML="";form.style.position="fixed";
		form.style.top="180px";
		form.style.zIndex="10001";
		form.style.width="420px";
		form.style.margin="0 auto";
		var n=form.childNodes.length;
		var d=form.childNodes[n-4];
		d.style.width="auto";
		d.style.height="auto";
		var a=d.childNodes[1];
		a.innerHTML="Enviar captcha";
		a.style.background="#333";
		a.style.fontWeight="bold";
		a.style.padding="3px 7px";
		a.style.color="#FFFFFF";
		a.style.textDecoration="none";
		a.style.display="inline";
		a.style.fontSize="12px";
		var p=d.parentNode;
		p.replaceChild(a,d);
		p.removeChild(p.getElementsByTagName("b")[0]);
		var br=p.getElementsByTagName("br");
		p.removeChild(br[0]);
		p.removeChild(br[0]);setTimeout("getFinalLink()",500);
		}
setTimeout("checkBanner()",500);
}

function getLink(){
	if(document.getElementById("captcha").style.display!='none'){
		getCaptcha();return;
		}else{
			var a=document.getElementById("downloadbutton_link");
			if(a.href.match(/download.php/i)){
				getFinalLink();return;}
				}
setTimeout("getLink()",500);
}

function checkBanner(){
	if(document.getElementById("captcha_advertising")){
		document.getElementById("captcha_advertising").innerHTML='';return;
		}
setTimeout("checkBanner()",500);
}

function getFinalLink(){
	var a=document.getElementById("downloadbutton_link");
	if(a.href.match(/download.php/i)){
		var hashes=window.location.href.slice(window.location.href.indexOf('?')+1).replace(/amp;/gi,'');
		var h=hashes.split('&'),hash,vars=[];
		for(var i=0;i<h.length;i++){
			hash=h[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]]=hash[1];
			}
			
var id=vars['id'] ;
var final=a.href.replace("http://", "");
window.location='<?=$msURL?>/stream/play.php?url='+final+'&count=20&'+hashes;
return;
}
setTimeout("getFinalLink()",100);
}
<?
exit();
}
if($_GET['tipo']=="ffactory"){
	header('Content-type: text/javascript');	
?>
if(location.href.match(/\.mp4$/i)){
	var box=document.createElement("div");
	box.style.backgroundColor="#000000";
	box.style.color="#FFFFFF";
	box.style.width="100%";
	box.style.height="100%";
	box.style.position="absolute";
	box.style.top="0";
	box.style.left="0";
	box.style.textAlign="center";
	box.style.fontSize="12px";
	box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
	box.style.zIndex="10000";
	document.body.appendChild(box);
	var logo=document.createElement("div");
	logo.style.paddingTop="50px";
	logo.align='center';
	box.appendChild(logo);
logo.innerHTML="<a style='float:left;height:65px;width:309px;margin:5px;overflow:hidden;'  href='<?=$msURL?>/'><img src='<?=$msURL?>/Temas/default/img/bg.png' alt='<?=$msTitulo?>' /></a>";
	var box2=document.createElement("div");
	box2.style.paddingTop="50px";
	box.appendChild(box2);
	
	if(document.getElementById("downloadLinkTarget")){
		getLink();
		}else{
			var but=document.getElementById("basicLink");
			document.body.style.overflow="hidden";
			if(but){
				box2.appendChild(but);
				but.innerHTML="Click aquí para cargar el video";
				but.className='';
				but.style.background="#333";
				but.style.fontWeight="bold";
				but.style.padding="3px 7px";
				but.style.color="#FFFFFF";
				but.style.textDecoration="none";
				if(but.addEventListener){
					but.addEventListener("click",clickBut,false);
					}else{
						but.attachEvent("onlick",clickBut);}
						}else{
							var pag=document.body.innerHTML;
							if(pag.match(/this file is no longer available/i)){
								box2.innerHTML="El archivo ha sido eliminado de Filefactory.";
								}
								}
								}
								}
function clickBut(e){
	but.innerHTML="Cargando...";
	if(but.removeEventListener){
		but.removeEventListener("click",clickBut,false);
		}else{
			but.detachEvent("onlick",clickBut);
			}
setTimeout("getCaptcha()",200);
}

function getCaptcha(){
	if(document.getElementById("recaptcha_area")){
		var form=document.getElementById("ffRecaptcha");
		var ra=document.getElementById("recaptcha_area");
		ra.style.margin="0 auto 15px";
		but.innerHTML="Enviar captcha";
		but.style.marginTop="15px";
		form.appendChild(but);
		box2.appendChild(form);return;
		}
setTimeout("getCaptcha()",200);
}
function getLink(){
	if(document.getElementById("basicTimer")){
		var d=parseInt(document.getElementById("basicTimer").childNodes[1].innerHTML);
		if(d>100){
			box2.innerHTML="Has superado el límite de descarga en Filefactory. Puedes volver a descargar en "+d+" segundos o puedes <a href='http://www.filefactory.com/premium/' target='_blank'>comprar una cuenta premium en Filefactory</a> para descargar sin límites.";
			setTimeout("getLink()",1000)
			return;
			}else if(d>20){
				box2.innerHTML="Por favor espera "+(d-20)+" segundos.";
				setTimeout("getLink()",1000)
return;}
}
var a=document.getElementById("downloadLinkTarget");
var ff=location.href.match(/dlf\/f\/([a-z0-9]+)\//i);
var final=a.href.replace("http://", "");
window.location='<?=$msURL?>/stream/play.php?url='+final+'&count=20&factory='+ff[1];}
<?
exit();
}
if($_GET['tipo']=="fsonic"){
	header('Content-type: text/javascript');
?>
var but=document.getElementById("free_download");
var box=document.createElement("div");
box.style.backgroundColor="#000000";
box.style.color="#FFFFFF";
box.style.width="640px";
box.style.height="360px";
box.style.position="absolute";
box.style.top="0";
box.style.left="0";
box.style.textAlign="center";
box.style.fontSize="12px";
box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
box.style.zIndex="10000";
document.body.appendChild(box);
var box2=document.createElement("div");
box2.style.paddingTop="160px";
box.appendChild(box2);
if(but){
	box2.appendChild(but);
	but.innerHTML="Click aquí para cargar el video";
	but.className='';
	but.style.background="#333";
	but.style.fontWeight="bold";
	but.style.padding="3px 7px";
	but.style.color="#FFFFFF";
	but.style.textDecoration="none";
	but.addEventListener("click",clickBut,false);
	}else{
		var pag=document.body.innerHTML;
		if(pag.match(/Your download link has expired/i)){
			box2.innerHTML="Tu descarga ha expirado. Debes volver a realizarla.";
			}else if(pag.match(/File not available/i)){
				box2.innerHTML="El archivo ha sido eliminado de Filesonic.";}
				}
function clickBut(e){
	but.innerHTML="Cargando...";
	but.removeEventListener("click",clickBut,false);
	document.getElementById("output").addEventListener("DOMNodeInserted",loadCaptcha,false);
	}
function loadCaptcha(){
	if(document.getElementById("captchaForm")){
		document.getElementById("output").removeEventListener("DOMNodeInserted",loadCaptcha,false);
		getCaptcha();return;
		}else if(document.getElementById("freeUserDelay")){
			var m=parseInt(document.getElementById("countdown").innerHTML);if(m>0){
				var q=document.getElementById("countdown").innerHTML.match(/min/i)?"minutos":"segundos";
				var msg=(q=="minutos")?"Has llegado al límite de descarga en Filesonic. Puedes volver a descargar en ":"Por favor, espera ";
				var msg2=(q=="minutos")?" o puedes <a href='http://www.filesonic.com/premium' target='_blank'>comprar una cuenta premium en Filesonic</a> para descargar sin límites":"";
				box2.innerHTML=msg+m+" "+q+msg2+".";
				}
return;
}else if(document.getElementById("downloadLink")){
	document.getElementById("output").removeEventListener("DOMNodeInserted",loadCaptcha,false)
	;getLink();
	return;
	}else if(document.getElementById("downloadErrors")){
		document.getElementById("output").removeEventListener("DOMNodeInserted",loadCaptcha,false);
		getError();
		return;}
		}
function goTimer(){
	var s=document.getElementById("timmer").innerHTML;document.getElementById("captchaError").style.display="none";
	var cap=document.getElementById("captchaArea");
	cap.style.display="block";
	cap.innerHTML="Por favor, espera "+s+" segundos";
	if(parseFloat(s)==0){
		setTimeout("getLink()",100);
		}
		}
function getCaptcha(){
	if(document.getElementById("captchaForm")){
		var form=document.getElementById("captchaForm");
		form.style.position="fixed";
		form.style.top="100px";
		form.style.left="130px";
		form.style.zIndex="10001";
		but.style.display="none";
		var inputs=form.getElementsByTagName("input");
		var but2=inputs[inputs.length-1];
		but2.value="Enviar captcha";
		document.getElementById("output").addEventListener("DOMNodeInserted",loadCaptcha,false);
		}
		}
function getLink(){
	var d=document.getElementById("downloadLink").innerHTML;
	if(d.match(/(comenzar la descarga ahora|download now)/i)){
		var a=document.getElementById("downloadLink").getElementsByTagName("a")[0];
		var hashes=window.location.href.slice(window.location.href.indexOf('?')+1).replace(/amp;/gi,'');
        var final=a.href.replace("http://", "");
		window.location='<?=$msURL?>/stream/play.php?url='+final+'&count=1&'+hashes;}
		}
function getError(){
	var d2=document.getElementById("downloadErrors").innerHTML;
	if(d2.match(/Free users may only download 1 file at a time/i)){
		box2.innerHTML="Ya estás descargando un archivo desde Filesonic. <br />No puedes cargar más de 1 archivo en simultáneo sin una cuenta premium en Filesonic.com (<a href='http://www.filesonic.com/premium' target='_blank'>comprar una cuenta premium en Filesonic</a>).";
		}
		}
<?
exit();
}
if($_GET['tipo']=="hotfile"){
	header('Content-type: text/javascript');
?>
var but=getButton();
var box=document.createElement("div");
box.style.backgroundColor="#000000";
box.style.color="#FFFFFF";
box.style.width="100%";
box.style.height="100%";
box.style.position="absolute";
box.style.top="0";
box.style.left="0";
box.style.textAlign="center";
box.style.fontSize="12px";
box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
box.style.zIndex="10000";
document.body.appendChild(box);
var logo=document.createElement("div");
logo.style.paddingTop="50px";
logo.align='center';
box.appendChild(logo);
logo.innerHTML="<a style='float:left;height:65px;width:309px;margin:5px;overflow:hidden;'  href='<?=$msURL?>/'><img src='<?=$msURL?>/Temas/default/img/bg.png' alt='<?=$msTitulo?>' /></a>";
var box2=document.createElement("div");
box2.id="box2"
box2.style.paddingTop="50px";
box.appendChild(box2);
document.body.style.overflow="hidden";

if(document.getElementById("dwltmr")&&document.getElementById("dwltmr").innerHTML.match(/You are currently downloading/i)){
	box2.innerHTML="Ya estás descargando un archivo de Hotfile.<br />No puedes descargar más de 1 archivo en simultáneo sin una cuenta premium en Hotfile.com (<a href='http://www.hotfile.com/premium.html' target='_blank'>comprar una cuenta premium en Hotfile</a>).";
	}else 
	if(but&&but.value.match(/REGULAR DOWNLOAD/gi)){
		var pag=document.body.innerHTML;
		if(pag.match(/Wrong code/i)){
			box2.innerHTML="El código ingresado no es correcto. Vuelve a intentarlo.<br />";
			}
regetButton();
but.addEventListener("click",clickBut,false);
}else if(getElementByClass("click_download")){
	getURL();
	}else 
	if(document.getElementById("recaptcha_widget_div")){
		loadCaptcha();
		}else{
			var pag=document.body.innerHTML;
			if(pag.match(/This file is either removed due to copyright claim or is deleted by the uploader/i)){
				box2.innerHTML="El archivo ha sido eliminado de Hotfile.";}
				}

function clickBut(e){
	but.value="Cargando...";
	but.removeEventListener("click",clickBut,false);
	var t=document.getElementById("dwltmr");
	if(t.innerHTML.match(/You reached your hourly traffic limit/i)){
		checkTime();
		document.getElementById("dwltxt").addEventListener("DOMSubtreeModified",checkTime,false);
		document.getElementById("freebut").removeEventListener("DOMSubtreeModified",regetButton,false);
		}else{
			t.addEventListener("DOMSubtreeModified",goTimer,false);
			}
			}

function loadCaptcha(){
	var forms=document.getElementsByTagName("form");
	var f=forms[forms.length-1];
	box2.appendChild(f);
	document.getElementById("box2").style.paddingTop="80px";
	var but2=getElementByClass("but");
	but2.value="Enviar captcha";
	var t=getElementByClass("tbl").getElementsByTagName("tr");
	t[0].firstChild.style.paddingLeft="0px";
	t[t.length-1].innerHTML="";
	}

function goTimer(){
	var s=parseInt(document.getElementById("dwltmr").firstChild.firstChild.innerHTML.replace(/([^0-9])+/gi,''));
	box2.innerHTML="Por favor, espera "+s+" segundos";if(s==0){setTimeout("getLink()",100);}
	}

function checkTime(){
	var d=document.getElementById("dwltxt");
	var dw=d.firstChild.getElementsByTagName("span")[0].innerHTML;
	var s=parseInt(dw.replace(/([^0-9])+/gi,''));
	if(s>0){
	var q=dw.match(/minutes/i)?"minutos":"segundos";
	box2.innerHTML="Has llegado al límite de descarga en Hotfile. Puedes volver a descargar en "+s+" "+q+" o puedes <a href='http://www.hotfile.com/premium.html' target='_blank'>comprar una cuenta premium en Hotfile</a> para descargar sin límites.";
	}else{
		d.removeEventListener("DOMSubtreeModified",checkTime,false);}
	}

function getLink(){
	if(!document.getElementById("captcha")){
		box2.innerHTML="Cargando...";
		setTimeout("getLink()",100);}
		}

function getURL(){
	if(getElementByClass("click_download")){
		var a=getElementByClass("click_download"),hashes=window.location.href.slice(window.location.href.indexOf('?')+1).replace(/amp;/gi,'').replace(/lang=en/i,'');
		var h=hashes.split('&'),hash,vars=[];
		for(var i=0;i<h.length;i++){
			hash=h[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]]=hash[1];
			}
var id=vars['id'],tipo=(vars['tipo']=="s")?'series':'peliculas',epi=(tipo=='series')?'/episodio':'';
var final=a.href.replace("http://", "");
window.location='<?=$msURL?>/stream/play.php?url='+final+'&count=20&'+hashes;}
}

function getElementByClass(theClass){
	var allHTMLTags=document.getElementsByTagName("*");
	for(i=0;i<allHTMLTags.length;i++){if(allHTMLTags[i].className==theClass){
		return allHTMLTags[i];}
		}
return false;
}

function getButton(){
	var form=document.getElementsByName("f");
	if(form){form=form[0];var inputs=document.getElementsByTagName("input");var intot=inputs.length;if((intot-2)>=0){return inputs[intot-2];}else{return false;}}else{return false;}}

function regetButton(){var but=getButton();box2.innerHTML="";box2.appendChild(but);but.value="Click aquí para cargar el video";but.className='';but.style.background="#333";but.style.fontWeight="bold";but.style.padding="3px 7px";but.style.color="#FFFFFF";but.style.border="0px";but.style.width="auto";but.style.height="auto";but.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";but.addEventListener("click",clickBut,false);}
<?
exit();
}
if($_GET['tipo']=="mega"){
	header('Content-type: text/javascript');
?>
var box=document.createElement("div");
box.style.backgroundColor="#000000";
box.style.color="#FFFFFF";
box.style.width="640px";
box.style.height="360px";
box.style.position="absolute";
box.style.top="0";
box.style.left="0";
box.style.textAlign="center";
box.style.fontSize="12px";
box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
box.style.zIndex="100000";
document.body.appendChild(box);
var box2=document.createElement("div");
box2.id="box2";
box2.style.paddingTop="80px";
box.appendChild(box2);
if(document.getElementById('captchaform')){
	var capForm=document.getElementById('captchaform');
	var captchacode=capForm.elements[0].value;
	var megavar=capForm.elements[1].value;
	var captchaimage=capForm.parentNode.getElementsByTagName('img')[0].src;
	var capHTML='<div align="center">Por favor, ingresa el código debajo para ver el video:</div><div style="background: url(<?=$msURL?>/stream/img/captcha_bg.gif) repeat-x;text-align:center;width:200px;margin:15px 220px;padding:10px;-webkit-border-radius:3px;-moz-border-radius:3px"><form method="POST" id="captchaform" style="padding:0;margin:0"><input type="hidden" name="captchacode" value="'+captchacode+'"><input type="hidden" name="megavar" value="'+megavar+'"><div><img src="'+captchaimage+'" border="0" style="background-color:white"></div><div style="margin-top:10px"><input type="text" name="captcha" id="captchafield" maxlength="4" style="text-transform:capitalize; text-transform:uppercase; font-size:20px; border:solid 1px; background-color:#FFFFFF; text-align:center; width:80px; height:30px; border:0; color:#000"></div><div align="center" style="margin-top:20px;"></div><input type="submit" value="Enviar código" style="font-size:11px;font-weight:bold;color:#000000;background:#CCCCC;border:0;border-right:1px solid #999999;border-bottom:1px solid #999999;-webkit-border-radius:3px;-moz-border-radius:3px;padding:3px 7px;" /></form></div></div>';
	box2.innerHTML=capHTML;
	}else if(document.getElementById('downloadlink')||getElementByClass('down_ad_butt1')){
		var hashes=window.location.href.slice(window.location.href.indexOf('?')+1).replace(/amp;/gi,'');
		var d=document.getElementById('downloadlink');
		var downloadlink;
		if(d){
			downloadlink=d.firstChild.href;
		}else{
			d=getElementByClass('down_ad_butt1');
			downloadlink=d.href;hashes+="&premium=true";}
var count=document.getElementById("countdown")?document.getElementById("countdown").innerHTML:45;
var final=downloadlink.replace("http://", "");
window.location='<?=$msURL?>/stream/play.php?url='+final+'&count='+count+'&'+hashes;
}else{var pag=document.body.innerHTML;
if(pag.match(/Unfortunately, the link you have clicked is not available/i)||pag.match(/El archivo al que está intentando acceder está temporalmente desactivado/i)||pag.match(/Lamentablemente, el enlace seleccionado no está disponible/i)){
	box2.innerHTML="Lamentablemente, el archivo que intentas ver está temporalmente desactivado. Prueba dentro de unos minutos.";}}
function getElementByClass(theClass){var allHTMLTags=document.getElementsByTagName("*");for(i=0;i<allHTMLTags.length;i++){if(allHTMLTags[i].className==theClass){return allHTMLTags[i];}}
return false;}
<?
exit();
}
if($_GET['tipo']=="mfire"){
	header('Content-type: text/javascript');
?>
var tit=getElementByClass("download_file_title");
if(tit){
	if(tit.innerHTML.match(/\.mp4/i)){
		var box=document.createElement("div");
		box.style.backgroundColor="#000000";
		box.style.color="#FFFFFF";
		box.style.width="640px";
		box.style.height="360px";
		box.style.position="absolute";
		box.style.top="0";
		box.style.left="0";
		box.style.textAlign="center";
		box.style.fontSize="12px";
		box.style.fontFamily="'Lucida Grande', Arial, Helvetica, sans-serif";
		box.style.zIndex="10000";
		document.body.appendChild(box);
		var box2=document.createElement("div");
		box2.id="box2";
		box2.style.paddingTop="160px";
		box.appendChild(box2);
		box2.innerHTML="Cargando, por favor espera...";
		setTimeout("getLink()",3000);
			}
		
	}
function getElementByClass(theClass){
	var allHTMLTags=document.getElementsByTagName("*");
	for(i=0;i<allHTMLTags.length;i++){if(allHTMLTags[i].className==theClass){return allHTMLTags[i];}}
return false;
}

function getLink(){
var t=document.getElementById("download_visible_wrapper").childNodes;console.log(t[5].childNodes[1].childNodes[1].childNodes[0].childNodes[3].childNodes[1].childNodes);var d=t[5].childNodes[1].childNodes[1].childNodes[0].childNodes[3].childNodes[1];var divs=d.getElementsByTagName("div");var a;for(i=0;i<divs.length;i++){if(divs[i].style.display=="block"&&divs[i].style.position!="absolute"){a=divs[i].firstChild;break;}}
if(a.href!=null&&a.href!='undefined'){var hashes=window.location.href.slice(window.location.href.indexOf('?')+1).replace(/amp;/gi,'');
var final=a.href.replace("http://", "");
window.location='<?=$msURL?>/stream/play.php?url='+final+'&count=20&mfire='+hashes;

}else{
	setTimeout("getLink()",1000);
	}
	}
<?
exit();
}else{
	echo('LOLAZO!!! TRRRP!');
	}
?>