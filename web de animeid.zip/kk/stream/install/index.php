<?
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
/* <CABECERAS GENERALES> */
$msLevel = 4; // Nivel de acceso de esta página
if(!isset($_SESSION)) session_start();//SI NO EXISTE SESION LA CREA
/* <clases> */
include("../../config.php");
include("../../inc/class/c.db.php");
include("../../inc/class/c.core.php");
include("../../inc/class/c.usuarios.php"); 
/* </clases> */

/* <obtencion de datos> */
$msdb =& msMySQL::getInstance();//BASES DE DATOS
$msCore	=& msCore::getInstance();//OBTENER DATOS DE MOVIESCRIPT
$msUser	=& msUsuarios::getInstance();//DATOS DEL USUARIO
$msLevelMsg = $msCore->setLevel($msLevel, true);//OBTENER NIVEL DE PAGINA
	/* <REDIRECCION> */
	if($msLevelMsg != 1){	
		header('Location: /');
		exit();
	}
		/* </REDIRECCION> */
$msConfig=$msCore->settings;
$msTitulo=$msConfig['datos']['w_titulo'];// TITULO
$msURL=$msConfig['datos']['w_url'];// URL
/* </obtencion de datos> */

/* </CABECERAS GENERALES> */

	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Instalar</title>
<style type="text/css">
-->
body{
	font-family:Verdana, Geneva, sans-serif;
}
h1{
	text-align:center;
}
p{
	text-align:justify;
	}
	input{
		text-align:center; }
-->
</style>
</head>
<body>
<?
if($_GET['paso']==1){
	if(!file_exists('../key.php')){
		$cod = substr(md5(uniqid(rand())),0,5);
		$l= fopen('../key.php','a');
		fwrite($l,'<? define("KEY","'.$cod.'"); ?>');
		fclose($l); 
	}else{
		include('../key.php');
		$cod=KEY;
		}
@ $lol= $msdb->query("SET NAMES 'utf8'");
$create = "CREATE TABLE IF NOT EXISTS `ms_stream` (
	`pelicula`	text,
	`id`	text,
	`subs`	text,
	`bitshare`	text,
	`ffactory`	text,
	`hotfile`	text,
	`mega` text,
	`mfire`	text
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";

$lol2=$msdb->query($create);
if(!is_dir('../../files/sub/')){
	mkdir('../../files/sub/', 0777);
	chmod('../../files/sub/',  0777);
	}
	?>
<h1>Listo!...</h1>
<p>En este paso se crearon las bases de datos necesarias. y un codigo unico para tu plugin y tu web, el cual es <strong><?=$cod?></strong>, este reconocera tu web de entre otras que podrian tener el mismo plugin.</p>
<p>Ahora basta con que hagas los plugins para <strong>Google Chrome y para Mozilla Firefox.</strong> esto es <strong>mas facil</strong> puesto que con este script solo necesitas descargar ciertos<strong> archivos ya preparado</strong> para este. Igualmente te crearemos una<strong> guia de instalacion</strong> para cada uno.</p>
<p><font color="#FF0000"><strong>NOTA: NO ES NECESARIO EDITAR NINGUNA ARCHIVO!</strong></font></p>
<h1>Guia Mozilla Firefox</h1>
<p>Para crear el script necesitaras lo siguiente</p>
<ol>
  <li>WinRar</li>
  <li><a href="/stream/des/rdf">install.rdf [click aqui para descargar]</a></li>
  <li><a href="/stream/des/script-compiler"> script-compiler.js [click aqui para descargar]</a></li>
  <li><a href="/stream/des/stream?e=firefox"> videostream.js [click aqui para descargar]</a></li>
</ol>
<p>Ahora solo vamos a la carpeta <strong>&quot;no upload&quot;</strong> que se encuentran en la paqueteria de este script, entramos a la carpeta <strong>&quot;firefox&quot;</strong> y veremos lo siguiente.</p>
<img src="1f.png"  />
<p>Ahi pondremos el archivo<strong> install.rdf, </strong>el cual quedara asi.</p>
<img src="2f.png"  />
<p>Ahora ponemos los archivos<strong> script-compiler.js y videostream.js</strong> en la carpeta<strong> &quot;content&quot;</strong>, quedara de la siguiente manera</p>
<img src="3f.png"  />
<p>Regresamos a la carpeta madre<strong> &quot;firefox&quot;,</strong> seleccionamos los archivos y los <strong>comprimimos en zip.</strong></p>
<p><img src="4f.png"  />
</p>
<p>Ahora le cambiamos la extencion <strong>&quot;.zip&quot; a &quot;.xpi&quot;</strong> y lo subimos a <strong>&quot;stream/plugins/&quot;</strong></p>
<p><img src="5f.png" /></p>
<p><strong>NOTA: El nombre del plugin en la carpeta &quot;stream/plugins/&quot; debe de quedar, si o si &quot;firefox.xpi&quot; </strong></p><br />

<h1>Guia Google Chrome</h1>
<p>Para crear el script necesitaras lo siguiente</p>
<ol>
  <li>Google Chrome</li>
  <li><a href="/stream/des/stream?e=chrome">go.js [click aqui para descargar]</a></li>
  <li><a href="/stream/des/manifest"> manifest.json [click aqui para descargar]</a></li>
</ol>
<p>Ahora solo vamos a la carpeta <strong>&quot;no upload&quot;</strong> que se encuentran en la paqueteria de este script, entramos a la carpeta <strong>&quot;chrome&quot;</strong> y veremos lo siguiente.</p>
<p><img src="1gc.png" /></p>
<p>Ahi pondremos los archivos <strong>&quot;go.js&quot; y &quot;manifest.json&quot;</strong>, de la siguiente manera.</p>
<p><img src="2gc.png" /></p>
<p>Ahora abrimos Google Chrome, vamos a <strong>Opciones&gt;Herramientas&gt;Extenciones</strong></p>
<p><img src="3gc.png" /></p>
<p>Ya ahi daremos click a <strong>Extension de empaque</strong></p>
<p><img src="4gc.png" /></p>
<p>Ahora daremos click al boton <strong>&quot;Navegar&quot;</strong> correspondiente a<strong> &quot;Directorio raiz de la extencion&quot;</strong> y seleccionamos la carpeta<strong> &quot;chrome&quot; </strong>en la que acabamos de bajar nuestros archvios y damos click en aceptar.</p>
<p><img src="5gc.png" /></p>
<p>Despues damos click en <strong>aceptar</strong> y te saldra la direccion donde se guardo nuestra extension en nuestra pc, esa misma la subiremos a la carpeta <strong>&quot;stream/plugins/&quot;</strong></p>
<img src="6gc.png"  />
<p><strong>NOTA: El nombre del plugin en la carpeta &quot;stream/plugins/&quot; debe de quedar, si o si &quot;chrome.crx&quot; </strong></p><br />
<br />
<h1>Finalizar la instalacion</h1>
<p>Al dar click al siguiente boton terminara la instalacion y seras redirigido a la administracion del el script, solo si ya subiste los dos plugins, tanto el de Google Chrome, como el de Mozilla Firefox, de lo contrario volveras a ver esta pagina.</p>
<p>Gracias por instalar, puedes continuar.</p>
<form action="../index.php" method="post"><input type="submit" value="Finalizar Instalacion" /></form>
</body>
</html>
<? 
	exit();
	}elseif($_GET['only']=="firefox"){
		?>
        <p><font color="#FF0000"><strong>NOTA: NO ES NECESARIO EDITAR NINGUNA ARCHIVO!</strong></font></p>
        
        <h1>Guia Mozilla Firefox</h1>
<p>Para crear el script necesitaras lo siguiente</p>
<ol>
  <li>WinRar</li>
  <li><a href="/stream/des/rdf">install.rdf [click aqui para descargar]</a></li>
  <li><a href="/stream/des/script-compiler"> script-compiler.js [click aqui para descargar]</a></li>
  <li><a href="/stream/des/stream?e=firefox"> videostream.js [click aqui para descargar]</a></li>
</ol>
<p>Ahora solo vamos a la carpeta <strong>&quot;no upload&quot;</strong> que se encuentran en la paqueteria de este script, entramos a la carpeta <strong>&quot;firefox&quot;</strong> y veremos lo siguiente.</p>
<img src="1f.png"  />
<p>Ahi pondremos el archivo<strong> install.rdf, </strong>el cual quedara asi.</p>
<img src="2f.png"  />
<p>Ahora ponemos los archivos<strong> script-compiler.js y videostream.js</strong> en la carpeta<strong> &quot;content&quot;</strong>, quedara de la siguiente manera</p>
<img src="3f.png"  />
<p>Regresamos a la carpeta madre<strong> &quot;firefox&quot;,</strong> seleccionamos los archivos y los <strong>comprimimos en zip.</strong></p>
<p><img src="4f.png"  />
</p>
<p>Ahora le cambiamos la extencion <strong>&quot;.zip&quot; a &quot;.xpi&quot;</strong> y lo subimos a <strong>&quot;stream/plugins/&quot;</strong></p>
<p><img src="5f.png" /></p>
<p><strong>NOTA: El nombre del plugin en la carpeta &quot;stream/plugins/&quot; debe de quedar, si o si &quot;firefox.xpi&quot; </strong></p><br />
<form action="../index.php" method="post"><input type="submit" value="Finalizar Instalacion" /></form>
        <?
		exit();
		}elseif($_GET['only']=="chrome"){
		?>
        <p><font color="#FF0000"><strong>NOTA: NO ES NECESARIO EDITAR NINGUNA ARCHIVO!</strong></font></p>
        <h1>Guia Google Chrome</h1>
<p>Para crear el script necesitaras lo siguiente</p>
<ol>
  <li>Google Chrome</li>
  <li><a href="/stream/des/stream?e=chrome">go.js [click aqui para descargar]</a></li>
  <li><a href="/stream/des/manifest"> manifest.json [click aqui para descargar]</a></li>
</ol>
<p>Ahora solo vamos a la carpeta <strong>&quot;no upload&quot;</strong> que se encuentran en la paqueteria de este script, entramos a la carpeta <strong>&quot;chrome&quot;</strong> y veremos lo siguiente.</p>
<p><img src="1gc.png" /></p>
<p>Ahi pondremos los archivos <strong>&quot;go.js&quot; y &quot;manifest.json&quot;</strong>, de la siguiente manera.</p>
<p><img src="2gc.png" /></p>
<p>Ahora abrimos Google Chrome, vamos a <strong>Opciones&gt;Herramientas&gt;Extenciones</strong></p>
<p><img src="3gc.png" /></p>
<p>Ya ahi daremos click a <strong>Extension de empaque</strong></p>
<p><img src="4gc.png" /></p>
<p>Ahora daremos click al boton <strong>&quot;Navegar&quot;</strong> correspondiente a<strong> &quot;Directorio raiz de la extencion&quot;</strong> y seleccionamos la carpeta<strong> &quot;chrome&quot; </strong>en la que acabamos de bajar nuestros archvios y damos click en aceptar.</p>
<p><img src="5gc.png" /></p>
<p>Despues damos click en <strong>aceptar</strong> y te saldra la direccion donde se guardo nuestra extension en nuestra pc, esa misma la subiremos a la carpeta <strong>&quot;stream/plugins/&quot;</strong></p>
<img src="6gc.png"  />
<p><strong>NOTA: El nombre del plugin en la carpeta &quot;stream/plugins/&quot; debe de quedar, si o si &quot;chrome.crx&quot; </strong></p><br />
<form action="../index.php" method="post"><input type="submit" value="Finalizar Instalacion" /></form>
        
        <?	
			exit();
			}
?>
<h1>Instalacion de videoStream Script v1.0</h1>
<p>El script es muy sencillo, tu subes <strong>videos .mp4</strong> (codificados en H624) a<strong> megaupload, bitshare, mediafire, entre otros</strong> y pegas el link en la<strong> administracion</strong>, llenas algunos datos, como por ejemplo <strong>subtitulos</strong> etc, y se creara un codigo para obtener un reproductor<strong> (solo podra usarse en tu web)</strong>, para que lo uses como<strong> reproductor en MovieScript</strong>. Despues este script obtendra la url de ese archivo y lo transmitira, esto hace que la transmision sea rapida y sin limites.</p>
<p>La instalacion, esta instalacion sera corta, auqnue un poco laboriosa en la parte de los plugins, leer paso a paso todo para instalar correctamente.</p>
<form action="?paso=1" method="post"><input type="submit" value="Instalar Ahora"></form>
    
</p>

</body>
</html>
