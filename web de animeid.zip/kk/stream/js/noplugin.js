function tabp(pos,cant){for(n=1;n<=cant;n++){if(document.getElementById("tabp_"+n)){if(n==pos){document.getElementById("tabp_"+n).className="selected";document.getElementById("block_"+n).style.display="block";}else{document.getElementById("tabp_"+n).className="";document.getElementById("block_"+n).style.display="none";}}}
recordar();}
var isFirefox=navigator.userAgent.indexOf('Firefox')>=0;function install(e){if(!isFirefox){return;}
var params={"Cuevana Stream":{URL:e.currentTarget.href,IconURL:e.currentTarget.getAttribute("iconURL"),toString:function(){return this.URL;}}};InstallTrigger.install(params);return false;}
function goDescarga(valor){if(valor==1){var newWindow=window.open("http://www.megaupload.com/?d="+duni,"_blank");newWindow.focus();return false;}else{parent.window.location="http://www.megaupload.com/?d="+duni;}}
function goDescarga2(valor){document.forms.down1.submit();return false;}
function goProxy(){var info=parent.document.getElementById("megaid").innerHTML;window.location="proxy-m.php?url="+info;return false;}
function createCookie(name,value,days){if(days){var date=new Date();date.setTime(date.getTime()+(days*24*60*60*1000));var expires="; expires="+date.toGMTString();}
else var expires="";document.cookie=name+"="+value+expires+"; path=/";}
function getCookie(c_name){if(document.cookie.length>0){c_start=document.cookie.indexOf(c_name+"=");if(c_start!=-1){c_start=c_start+ c_name.length+1;c_end=document.cookie.indexOf(";",c_start);if(c_end==-1)c_end=document.cookie.length;return unescape(document.cookie.substring(c_start,c_end));}}
return"";}
function recordar(){var el=document.getElementById("recordar");if(el.checked==true){for(i=1;i<=2;i++){if(document.getElementById("tabp_"+i).className=="selected"){var valor=i;}}
createCookie('cuevana_recordarop','si',30);createCookie('cuevana_opcionplay',valor,30);}else{createCookie('cuevana_recordarop','no',-1);}}
function checkRecordar(){if(getCookie("cuevana_recordarop")=="si"){tabp(getCookie("cuevana_opcionplay"),4);document.getElementById("recordar").checked=true;}}
window.onload=function(){checkRecordar();document.getElementById("player_frame_hide").style.display="none";}