<?
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
/* <CABECERAS GENERALES> */
$msLevel = 4; // Nivel de acceso de esta página
if(!isset($_SESSION)) session_start();//SI NO EXISTE SESION LA CREA
/* <clases> */
include("../config.php");
include("../inc/class/c.db.php");
include("../inc/class/c.core.php");
include("../inc/class/c.usuarios.php"); 
/* </clases> */

/* <obtencion de datos> */
$msdb =& msMySQL::getInstance();//BASES DE DATOS
$msCore	=& msCore::getInstance();//OBTENER DATOS DE MOVIESCRIPT
$msUser	=& msUsuarios::getInstance();//DATOS DEL USUARIO
$msLevelMsg = $msCore->setLevel($msLevel, true);//OBTENER NIVEL DE PAGINA
	/* <REDIRECCION> */
	if($msLevelMsg != 1){	
		header('Location: /');
		exit();
	}
		/* </REDIRECCION> */
$msConfig=$msCore->settings;
$msTitulo=$msConfig['datos']['w_titulo'];// TITULO
$msURL=$msConfig['datos']['w_url'];// URL
/* </obtencion de datos> */

/* </CABECERAS GENERALES> */

/* <REDIRECCION SANA> */
$rediri=array('key' => false, 'firefox' => false, 'chrome' => false);

if(file_exists('key.php')){
	$rediri['key']=true;
	}
if(file_exists('plugins/firefox.xpi')){
	$rediri['firefox']=true;
	}
if(file_exists('plugins/chrome.crx')){
	$rediri['chrome']=true;
	}
if($rediri['key']==false) { header('Location: install/index.php'); }else{ ?> <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Instalar</title>
<style type="text/css">
-->
body{
	font-family:Verdana, Geneva, sans-serif !important;
}
h1{
	text-align:center !important;
}
p{
	text-align:justify !important;
	}
	.loliz {
	text-align: left;
}
.lolder {
	text-align: left;
}
		.admin_table {border:1px solid #ddd; border-width:1px 0 0 1px;}
.admin_table thead {background:#F4F4F4}
.admin_table th, .admin_table td {padding:3px 4px;border:1px solid #ddd; border-width:0px 1px 1px 0px; vertical-align:middle; text-align:center}

-->
</style>

</head>
<body> <?     if($rediri['firefox']==false){ exit('<p>Al parecer no haz hecho el plugin de Mozilla Firefox <h1><a href="install/?only=firefox">Click aqui para crear</h1>');  }  if($rediri['chrome']==false){  exit('<p>Al parecer no haz hecho el plugin de Chrome<h1><a href="install/?only=chrome">Click aqui para crear</h1>');  }       }

	/* </REDIRECCION SANA> */

?>
<h1>Administracion!</h1>
<?
include('key.php');	
echo('KEY UNICA '.KEY.'');
if($_GET['edit']){ 

exit();}// EDITAR

if($_GET['codigo']){ 
$lol2=$msdb->query("SELECT id, subs FROM ms_stream WHERE id=".$_GET['codigo']."");
$atrup = mysql_fetch_assoc($lol2);
$codigo='<iframe id="player_frame" name="player_frame" marginwidth="0" marginheight="0" src="'.$msURL.'/stream/cambio.php?get=plugin" frameborder="0" height="360" scrolling="no" width="640"></iframe>
<div id="videoi" style="display:none;" class="hide">&amp;id='.$atrup['id'].'&amp;sub='.$atrup['subs'].'&amp;onstart=yes&amp;sub_pre=ES</div>';
					?>
					<h2>Codigo</h2>
					<p>El siguiente codigo lo tienes que poner como algun reproductor, no es necesario editar nada! :D</p>
					<textarea readonly="readonly" onclick="this.select()" cols="50" rows="4"><?=htmlentities($codigo);?></textarea>
					<br />
<a href="index.php">Volver!</a>
<?
exit();}// CODIGO UNICO

if($_GET['caca']){//ELIMINAR
	$caca=$msdb->query('DELETE FROM ms_stream WHERE id = "'.$_GET['caca'].'"');
	if(file_exists('../files/sub/'.$_GET['caca'].'_ES.srt')){ unlink('../files/sub/'.$_GET['caca'].'_ES.srt');}
	if(file_exists('../files/sub/'.$_GET['caca'].'_EN.srt')){ unlink('../files/sub/'.$_GET['caca'].'_EN.srt'); }
	 exit('<p><strong>Se elimino, u.u.</strong></p><br />
<a href="index.php">Volver!</a>');
	 }

if($_GET['new']){
	if($_POST){
		function e($e){
		$e = nl2br(htmlentities($e));
		$e = stripslashes($e);
		return $e ;
	}
		$name=e($_POST['nombre']);
		$sv=$_POST['servidores'];
		$svs=$_POST['servidores'];
		$sub_es= $_FILES['es'];
		$sub_en= $_FILES['en'];
		$subs=array('es' => $sub_es, 'en' => $sub_en, 'tons' => true);
		if(empty($name)){exit('<h2>Debes elejir un nombre ¬¬</h2>');}
		$id=mt_rand(1,9999);
		for($i=0;$i<4;$i++){
			if(empty($sv[$i])){
				$sv[$i]="no";
				}else{
				$sv[$i]="si";	
					}
			}
		if(!in_array("si",$sv)){
			die('<h2>Necesitas agregar alguna fuente de trasmision.</h2>');
			}
		if(empty($subs['es']['name'])){
				if(empty($subs['en']['name'])){
				$subs['tons']=false;
				}else{
					$subs['tons']='en';
				}
			}
			if(empty($subs['en']['name'])){
				if(empty($subs['es']['name'])){
				$subs['tons']=false;
				}else{
					$subs['tons']='es';
				}
			}
			if($subs['tons']==false){
				$subs['tons']=',';
				}elseif($subs['tons']==true){
					$subs['tons']=',ES,EN';
					$ext=strtolower(end(explode('.',$subs['es']['name'])));
					$exts=strtolower(end(explode('.',$subs['en']['name'])));
					if($ext=='srt' || $exts=='srt'){
						move_uploaded_file($subs['es']['tmp_name'],'../files/sub/'.$id.'_ES.srt');
						move_uploaded_file($subs['en']['tmp_name'],'../files/sub/'.$id.'_EN.srt');
						}else{
							exit('<h2>Los subtitulos deben de ser con extencion .srt</h2>');
							}
					
					}elseif($subs['tons']=='es'){
						$subs['tons']=',ES';
						$ext=strtolower(end(explode('.',$subs['es']['name'])));
					if($ext=='srt'){
						move_uploaded_file($subs['es']['tmp_name'],'../files/sub/'.$id.'_ES.srt');
						}else{
							exit('<h2>Los subtitulos deben de ser con extencion .srt</h2>');
							}
						}elseif($subs['tons']==',EN'){
							$subs['tons']=',EN';
												$exts=strtolower(end(explode('.',$subs['en']['name'])));
					if($exts=='srt'){
						move_uploaded_file($subs['en']['tmp_name'],'../files/sub/'.$id.'_EN.srt');
						}else{
							exit('<h2>Los subtitulos deben de ser con extencion .srt</h2>');
							}
							}
					
					$que = "INSERT INTO ms_stream (pelicula, id, subs, mega, mfire, bitshare, hotfile) ";
					$que.= "VALUES ('$name', '$id', '".$subs['tons']."', '".$svs[0]."', '".$svs[1]."', '".$svs[2]."', '".$svs[3]."') ";
					$waa=$msdb->query($que);
					$codigo='<iframe id="player_frame" name="player_frame" marginwidth="0" marginheight="0" src="'.$msURL.'/stream/cambio.php?get=plugin" frameborder="0" height="360" scrolling="no" width="640"></iframe>
<div id="videoi" style="display:none;" class="hide">&amp;id='.$id.'&amp;sub='.$subs['tons'].'&amp;onstart=yes&amp;sub_pre=ES</div>';
					?>
					<h2>Exito!!!</h2>
					<p>El siguiente codigo lo tienes que poner como algun reproductor, no es necesario editar nada! :D</p>
					<textarea readonly="readonly" onclick="this.select()" cols="50" rows="4"><?=htmlentities($codigo);?></textarea>
					<br />
<a href="index.php">Volver!</a>
<?
			
			
		
		}else{
			?>
            <form action="index.php?new=true" method="post" enctype="multipart/form-data">
            <h2>Agregar Pelicula!</h2>
<table width="500" border="0">
  <tr>
    <th class="loliz" scope="col"><strong>Nombre de pelicula:</strong></th>
    <th class="lolder" scope="col"><input size="30" border="2" name="nombre"  /></th>
  </tr>
  <tr>
    <th class="loliz" scope="row"><h3>Servidores
 disponibles:</h3></th>
    <td class="lolder">&nbsp;</td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Megaupload</strong></th>
    <td class="lolder">&nbsp;<input size="30" border="2" name="servidores[]"  /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Mediafire</strong></th>
    <td class="lolder">&nbsp;<input name="servidores[]" size="30" border="2"  /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Bitshare</strong></th>
    <td class="lolder">&nbsp;<input name="servidores[]" size="30" border="2"  /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Hotfile</strong></th>
    <td class="lolder">&nbsp;<input name="servidores[]" size="30" border="2"  /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><h3>Subtitulos:</h3></th>
    <td class="lolder">&nbsp;</td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Español:</strong></th>
    <td class="lolder"><input type="file" name="es" size="30" border="2" /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row"><strong>Ingles:</strong></th>
    <td class="lolder"><input type="file" name="en" size="30" border="2"  /></td>
  </tr>
  <tr>
    <th class="loliz" scope="row">&nbsp;</th>
    <td class="lolder">&nbsp;</td>
  </tr>
  <tr>
    <th class="loliz" scope="row">&nbsp;</th>
    <td class="lolder"><input  size="30" border="2" type="submit" value="Agregar pelicula" /></td>
  </tr>
</table>


</form>
<br />
<a href="index.php">Volver!</a>
            <?
			}
	
	 exit();}//NUEVO



?>
  <p>Aqui se mostraran las peliculas añadidas, puedes eliminarlas, ver codigo unico y obviamente crear nuevas.</p>
<?
$lol2=$msdb->query("SELECT * FROM ms_stream ORDER BY id ASC");
$chan = mysql_num_rows($lol2);
if ($chan> 0) {
	?>
     <table cellpadding="0" cellspacing="0" border="0" class="admin_table" width="100%" align="center">
	<thead>
		<tr>
			<th width="11%">ID</th>
			<th width="64%">Nombre</th>
			<th width="25%">Acciones</th>
		</tr>
	</thead>
	<tbody>
    <?
   while ($atrup = mysql_fetch_assoc($lol2)) {
	   ?>
      
        		<tr>
			<td><?=$atrup['id']?></td>
			<td><?=$atrup['pelicula']?></td>
			<td>
             <a href="<?=$msURL?>/stream/?codigo=<?=$atrup['id']?>" title="Codigo Unico"><img src="<?=$msURL?>/Temas/default/img/link.png" /></a> 
             <a onclick="if(confirm('Esta seguro que desea continuar?') == false){return false;}" href="<?=$msURL?>/stream/?caca=<?=$atrup['id']?>" title="Eliminar"><img src="<?=$msURL?>/Temas/default/img/close.png" /></a></td>
		</tr>
 
   <?
   
   }
   ?>
   
        	</tbody>
	<tfoot>
		<tr>
			<th colspan="3" ><p style="float:right;margin:5px;"><input type="button" onclick="location.href = '<?=$msURL?>/stream/?new=true'" class="btn_g" value="Agregar pelicula!"></p></th>
		</tr>
	</tfoot>
</table>
<?
}else{
echo('<p style="border:3px solid #CCC; padding:3ox;"><strong>No hay nada! u.u =(</strong></p><br /><br />
<input type="button" onclick="location.href = \''.$msURL.'/stream/?new=true\'" class="btn_g" value="Agregar pelicula!">');
}

?>
        
     