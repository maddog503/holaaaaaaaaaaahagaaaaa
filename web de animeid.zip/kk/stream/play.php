<?
/*
_  _ _ ___  ____ ____    ____ ___ ____ ____ ____ _  _    ____ ____ ____ _ ___  ___    _  _ _  ____ 
|  | | |  \ |___ |  |    [__   |  |__/ |___ |__| |\/|    [__  |    |__/ | |__]  |     |  | |  |  | 
 \/  | |__/ |___ |__|    ___]  |  |  \ |___ |  | |  |    ___] |___ |  \ | |     |      \/  | .|__| 
 Autor: dedydamy
 http://dedydamy.com
 Script Gratis
 Donaciones:  Paypal: dedydamy2@hotmail.com
                                                                                                
*/
include("../config.php");
include("../inc/class/c.db.php");
include("../inc/class/c.core.php");
$msdb =& msMySQL::getInstance();
$msCore	=& msCore::getInstance();
$msConfig=$msCore->settings;
$msTitulo=$msCore->settings['datos']['w_titulo'];
$msURL=$msConfig['datos']['w_url'];
if(!is_numeric($_GET['id'])){exit("BITCH!!!!!!!!!!!!!!");}
$ts=array('http://','https://','/');
$lol=str_replace($ts,"",$msURL);
$lol=str_replace('.','\.',$lol);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<title><?=$msTitulo?> | Reproducir video</title>
<link rel="stylesheet" href="css/play.css" type="text/css" />

<script type="text/javascript">
<!--

function error() {
	try {
		var n = top.location.toString();
		if (!n.match(/http:\/\/<?=$lol?>\//)) {
			out()
		}
	} catch(e) {
		out()
	}
}


function out() {
	top.location.href = "<?=$msURL?>";
	document.body.innerHTML = "Dirigete a <?=$msTitulo?> para ver películas y series gratis en calidad DVD.";
}
window.onload = function() {
	error()
}
//-->

function addScript(r) {
	var h = document.getElementsByTagName("head")[0], s = document.createElement("script");
	s.type="text/javascript";
	h.appendChild(s);
	s.text = r;
}
</script>

<script type="text/javascript" src="js/detectflash.js"></script>
<script type="text/javascript">
var count = <? if($_GET['premium']==true){echo('1');}else{echo($_GET['count']);}?>;
function downCount() {
	count--;
	document.getElementById("counterNum").innerHTML = count;
	if (count <= 0) {
		var isIE = /*@cc_on!@*/false;
		var swfHTML = (isIE) ? "<object height=\"360\" width=\"640\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" id=\"playerSWF\" ><param name=\"movie\" value=\"player4.swf\"><param name=\"flashvars\" value=\"megaurl=http://<?=$_GET['url']?>&id=<?=$_GET['id']?>&subs=<?=$_GET['sub']?>&onstart=yes&tipo=&amp;sub_pre=<?=$_GET['sub_pre']?>\"><param name=\"allowscriptaccess\" value=\"always\"><param name=\"allowfullscreen\" value=\"true\"><param name=\"bgcolor\" value=\"#000000\"><div><div>Es necesario disponer de Adobe Flash Player para ver este vídeo. <br> <a href=\"http:\/\/get.adobe.com\/flashplayer\/\">Descárgalo en la página de Adobe<\/a>.<\/div><\/div><\/object>" : "<embed height=\"360\" width=\"640\" type=\"application\/x-shockwave-flash\" src=\"player4.swf\" id=\"playerSWF\" name=\"playerSWF\" flashvars=\"megaurl=http://<?=$_GET['url']?>&id=<?=$_GET['id']?>&subs=<?=$_GET['sub']?>&onstart=yes&tipo=&amp;sub_pre=<?=$_GET['sub_pre']?>\" allowscriptaccess=\"always\" allowfullscreen=\"true\" bgcolor=\"#000000\" \/><noembed><div><div>Es necesario disponer de Adobe Flash Player para ver este vídeo. <br> <a href=\"http:\/\/get.adobe.com\/flashplayer\/\">Descárgalo en la página de Adobe<\/a>.<\/div><\/div><\/noembed>";
		document.body.innerHTML = swfHTML;
	} else {
		setTimeout("downCount()", 1000);
	}
}
</script>
</head>

<body>
<div id="zoom_1" style="top:2px;left:10%;width:10px;height:10px;position:absolute;visibility:hidden"> </div>

<div id="zoom_2" style="top:2px;width:10px;height:10px;position:absolute;visibility:hidden"> </div>
<div id="player_frame_count_hide" class="hideframe">
<div id="banner">
<!-- PORFAVOR NO QUITES PUBLICIDAD, DE ESO COME MI FAMILIA U.U -->
<script type="text/javascript"><!--
google_ad_client = "ca-pub-2604093247804094";
/*PORFAVOR NO QUITES PUBLICIDAD, DE ESO COME MI FAMILIA U.U */
google_ad_slot = "3070145686";
/*PORFAVOR NO QUITES PUBLICIDAD, DE ESO COME MI FAMILIA U.U */
google_ad_width = 300;
/*PORFAVOR NO QUITES PUBLICIDAD, DE ESO COME MI FAMILIA U.U */
google_ad_height = 250;
/*			GRACIAS!!!!!!!!! 			*/
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<!-- PORFAVOR NO QUITES PUBLICIDAD, DE ESO COME MI FAMILIA U.U -->
<p>Hacer click en el anuncio no interrumpirá la carga del video.</p></div>
<div id="all">
<div class="tip">Powered by <a href="http://marcofbb.com.ar" target="_blank">MovieScript</a> and <a href="http://dedydamy.com" target="_blank">Video Stream Script v1.0</a></div>
El video comenzará en<p><span id="counterNum"></span></p>
</div>

</div>
<script type="text/javascript">
var requiredMajorVersion = 9;
var requiredMinorVersion = 0;
var requiredRevision = 0;
var hasReqestedVersion = DetectFlashVer(requiredMajorVersion, requiredMinorVersion, requiredRevision);
if (hasReqestedVersion) {
	downCount();
} else {
	document.body.innerHTML = "<p>Necesitas tener instalado Flash Player 9 o superior para poder reproducir el video. Por favor descarga o actualiza Flash Player a la última versión desde <a href='http://get.adobe.com/es/flashplayer/' target='_blank'>aquí</a>.</p>";
}
</script>
</body>
</html>