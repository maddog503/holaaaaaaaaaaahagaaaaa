<?php
   include("conec.php");
   $link=Conectarse();
$Sql="insert into categoria (cat)  values ('".$_POST["cat"]."')";      
   mysql_query($Sql,$link); 
   header("Location: insertar-categoria.php");
?>