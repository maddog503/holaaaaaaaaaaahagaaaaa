<html>
<head>

<title>Agregar Anime</title>
<link rel="image_src" href="/img/imgfb.jpg">

<link rel="shortcut icon" href="favicon.ico">

<link href="/css/main.css" rel="stylesheet" type="text/css">

<base href="<?php echo $web; ?>">

<link rel="alternate" type="application/rss+xml" title="<?php echo $sitio; ?> RSS Feed" href="/rss.php">

<script type="text/javascript" src="/css/prototaculous.js"></script>

<script type="text/javascript" src="/css/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="/css/jquery.tipsy.js"></script>

<script type="text/javascript" src="/css/jquery.jtruncate.pack.js"></script>

<script type="text/javascript" src="/css/script.js"></script>

<script type="text/javascript"></script>

</head>
<body>
<div id="header"><div id="cb">
<!-- logo --><div id="l" class="c"><a href="http://www.animevision.org" title="<?php echo $sitio; ?>" style="float: left;"><iframe src="http://www.animevision.org/cabecera.html" border="0" marginwidth="0" marginheight="-50" height="100" width="280" scrolling="no" border="0" frameborder="0" name="logo"></iframe></a>
</div>
</div></div>

<div id="mm"><div id="eim"></div><div id="m">

<?php include("css/menu-post.php"); ?>

</div><div id="edm"></div></div></div>
<div id="main">

<h1>Agregar Categoria</h1>
<form action="agregar-categoria.php" method="post">
<TABLE>
<tr>
   <td>Categoria:</td>
   <td><input type="text" name="cat" size="20" ></td>
</tr>
</TABLE>
<input type="submit" name="accion" value="Grabar">
</FORM>
<hr>
<?php
   include("conec.php");
   $link=Conectarse();
   $result=mysql_query("select * from categoria",$link);
?>
</body>
</html>