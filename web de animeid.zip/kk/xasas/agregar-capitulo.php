<?php
   include("conec.php");
   $link=Conectarse();
$Sql="insert into capitulos (id_anime,nombre_capitulo,sub,opcn,embed,url)  values ('".$_POST["id_anime"]."','".$_POST["nombre_capitulo"]."','".$_POST["sub"]."', '".$_POST["opcn"]."', '".$_POST["embed"]."', '".$_POST["url"]."')";      
   mysql_query($Sql,$link); 
   header("Location: insertar-capitulo.php");
?>