<?php
   include("conec.php");
   $link=Conectarse();
$Sql="insert into animes (nombre,categoria,catg,agreg,titu,descripccion,imagen,estado)  values ('".$_POST["nombre"]."','".$_POST["categoria"]."','".$_POST["catg"]."', '".$_POST["agreg"]."', '".$_POST["titu"]."', '".$_POST["descripccion"]."','".$_POST["imagen"]."','".$_POST["estado"]."')";      
   mysql_query($Sql,$link); 
   header("Location: insertar-anime.php");
?>