<ul id="uno">
<li><a href="insertar-anime.php" class="menu">Agregar Anime</a></li>
<li><a href="insertar-capitulo.php" class="menu">Agregar Capitulo</a></li>
<li><a href="consulta-anime.php" target="_blank" class="menu">Editar Anime</a></li>
<li><a href="consulta-capitulo.php" target="_blank" class="menu">Edicar Capitulos</a></li>
<li><a href="lista.phtml" target="_blank" class="menu">Lista de Anime</a></li>
</ul>