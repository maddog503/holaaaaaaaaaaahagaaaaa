<html>
<head>
   <title>Agregar Capitulo</title>
<link rel="image_src" href="/img/imgfb.jpg">

<link rel="shortcut icon" href="favicon.ico">

<link href="/css/main.css" rel="stylesheet" type="text/css">

<base href="<?php echo $web; ?>">

<link rel="alternate" type="application/rss+xml" title="<?php echo $sitio; ?> RSS Feed" href="/rss.php">

<script type="text/javascript" src="/css/prototaculous.js"></script>

<script type="text/javascript" src="/css/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="/css/jquery.tipsy.js"></script>

<script type="text/javascript" src="/css/jquery.jtruncate.pack.js"></script>

<script type="text/javascript" src="/css/script.js"></script>

<script type="text/javascript"></script>

</head>
<body>
<div id="header"><div id="cb">
<!-- logo --><div id="l" class="c"><a href="http://www.animevision.org" title="<?php echo $sitio; ?>" style="float: left;"><iframe src="http://www.animevision.org/cabecera.html" border="0" marginwidth="0" marginheight="-50" height="100" width="280" scrolling="no" border="0" frameborder="0" name="logo"></iframe></a>
</div>
</div></div>

<div id="mm"><div id="eim"></div><div id="m">

<?php include("css/menu-post.php"); ?>

</div><div id="edm"></div></div></div>
<div id="main">
</head>
<body>
<h1>Agregar Capitulo</h1>
<form action="agregar-capitulo.php" method="post">
<TABLE>
<tr>
   <td>id_anime:</td>
   <td><input type="text" name="id_anime" size="20" maxlength="30"></td>
</tr>
<tr>
   <td>capitulo numero:</td>
   <td><input type="text" name="nombre_capitulo" size="20" maxlength="30"></td>
</tr>
<tr>
   <td>sub:</td>
   <td><input type="text" name="sub" size="20" maxlength="30" value="Sub Espa�ol"></td>
</tr>
<tr>
   <td>opcn:</td>
   <td><textarea name="opcn" cols="50" rows="3">
<li><a href="#tab1">Opci&oacute;n 1</a></li>
<li><a href="#tab2">Opci&oacute;n 2</a></li>
<li><a href="#tab3">MEGAVIDEO</a></li></textarea></td>
</tr>
<tr>
   <td>embed:</td>
   <td><textarea name="embed" cols="50" rows="19">
<div id="tab1" class="tab_content">

<iframe scrolling="no" src="http://www.pelispediaservicio.com.ar/movies/private?mu=&amp;ad=http://animevision.org/publicidad.html" style="border: none; height: 360px; width: 635px;"></iframe>

</div>
<div id="tab2" class="tab_content">


 
</div>
<div id="tab3" class="tab_content">


 
</div></textarea></td>
</tr>
<tr>
   <td>url:</td>
   <td><textarea name="url" cols="50" rows="2"><a href="" target="_blank"></a></textarea></td>
</tr>
</TABLE>
<input type="submit" name="accion" value="Grabar">
</FORM>
<hr>
<?php
   include("conec.php");
   $link=Conectarse();
   $result=mysql_query("select * from capitulos",$link);
?>
</body>
</html>