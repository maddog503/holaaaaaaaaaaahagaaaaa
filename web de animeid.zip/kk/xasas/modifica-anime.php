<?php
   include("conec.php");
   $link=Conectarse();   
$Sql="UPDATE animes SET id='".$_POST["id"]."', nombre='".$_POST["nombre"]."', categoria='".$_POST["categoria"]."', agreg='".$_POST["agreg"]."', titu='".$_POST["titu"]."', mini='".$_POST["mini"]."', descripccion='".$_POST["descripccion"]."', imagen='".$_POST["imagen"]."', estado='".$_POST["estado"]."' WHERE nombre='".$_POST["nombre"]."'"; 
   mysql_query($Sql,$link); 
   header("Location: consulta-anime.php");
?>