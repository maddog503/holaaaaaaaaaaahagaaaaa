<html>
<head>

<title>Agregar Anime</title>
<link rel="image_src" href="/img/imgfb.jpg">

<link rel="shortcut icon" href="favicon.ico">

<link href="/css/main.css" rel="stylesheet" type="text/css">

<base href="<?php echo $web; ?>">

<link rel="alternate" type="application/rss+xml" title="<?php echo $sitio; ?> RSS Feed" href="/rss.php">

<script type="text/javascript" src="/css/prototaculous.js"></script>

<script type="text/javascript" src="/css/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="/css/jquery.tipsy.js"></script>

<script type="text/javascript" src="/css/jquery.jtruncate.pack.js"></script>

<script type="text/javascript" src="/css/script.js"></script>

<script type="text/javascript"></script>

</head>
<body>
<div id="header"><div id="cb">
<!-- logo --><div id="l" class="c"><a href="http://animevision.org" title="Anime Online - <?php echo $sitio; ?> Online" style="float: left;"><iframe src="http://animevision.org/cabecera.html" border="0" marginwidth="0" marginheight="-50" height="100" width="280" scrolling="no" border="0" frameborder="0" name="logo"></iframe></a>
</div>
</div></div>

<div id="mm"><div id="eim"></div><div id="m">

<?php include("css/menu-post.php"); ?>

</div><div id="edm"></div></div></div>
<div id="main">

<h1>Agregar Anime</h1>
<form action="agregar-anime.php" method="post">
<TABLE>
<tr>
   <td>nombre del anime:</td>
   <td><input type="text" name="nombre" size="20" ></td>
</tr>
<tr>
   <td>categoria:</td>
   <td><select name="categoria">
  <option value="Anime" selected="selected">Anime</option>
  <option value="Ova">Ova</option>
  <option value="Pelicula">Pelicula</option>
</select></td>
</tr>
<tr>
   <td>catg:</td>
   <td><select name="catg">
  <option value="Anime" selected="selected">Anime</option>
  <option value="ova">ova</option>
  <option value="pelicula">pelicula</option>
</select></td>
</tr>
<tr>
   <td>fecha de agregado:</td>
   <td><input type="text" name="agreg" size="20" maxlength="30" value="0000-00-00"> (a�o-mes-dia)
</td>
</tr>
<tr>
   <td>titu:</td>
   <td><input type="text" name="titu" size="20" maxlength="30" value="ninguno" disabled="disabled"></td>
</tr>
<tr>
   <td>descripcion:</td>
   <td><textarea name="descripccion" cols="50" rows="3"></textarea></td>
</tr>
<tr>
   <td>imagen:</td>
   <td><input type="text" name="imagen" size="20" > Ejemplo: http://images.mcanime.net/images/anime/836.jpg</td>
</tr>
<tr>
   <td>estado:</td>
   <td><select name="estado">
  <option value="&lt;font color=&quot;#CC0000&quot;&gt;Finalizado&lt;/font&gt;" selected="selected">Finalizado</option>
  <option value="&lt;font color=&quot;#008000&quot;&gt;En Emision&lt;/font&gt;">En Emision</option>
</select></td>
</tr>

</TABLE>
<input type="submit" name="accion" value="Grabar">
</FORM>
<hr>
<?php
   include("conec.php");
   $link=Conectarse();
   $result=mysql_query("select * from animes",$link);
?>
</body>
</html>