<?php
function Conectarse(){
   if (!($link=mysql_connect("localhost","animevis_anime","D,(1!xT9O+JrSOMrNN")))  {
      exit();
   }
   if (!mysql_select_db("animevis_ruxel",$link)){
      exit();
   }
   return $link;
} 
?>