<html>
<link rel="image_src" href="/img/imgfb.jpg">

<link rel="shortcut icon" href="favicon.ico">

<link href="/css/main.css" rel="stylesheet" type="text/css">

<base href="<?php echo $web; ?>">

<link rel="alternate" type="application/rss+xml" title="<?php echo $sitio; ?> RSS Feed" href="/rss.php">

<script type="text/javascript" src="/css/prototaculous.js"></script>

<script type="text/javascript" src="/css/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="/css/jquery.tipsy.js"></script>

<script type="text/javascript" src="/css/jquery.jtruncate.pack.js"></script>

<script type="text/javascript" src="/css/script.js"></script>

<script type="text/javascript"></script>

</head>
<body>
<div id="header"><div id="cb">
<!-- logo --><div id="l" class="c"><a href="http://animevision.org" title="Anime Online - <?php echo $sitio; ?> Online" style="float: left;"><iframe src="cabecera.html" border="0" marginwidth="0" marginheight="-50" height="100" width="280" scrolling="no" border="0" frameborder="0" name="logo"></iframe></a>
</div>
</div></div>

<div id="mm"><div id="eim"></div><div id="m">

<?php include("css/menu-post.php"); ?>

</div><div id="edm"></div></div></div>
<div id="main">
<?php
   include("conec.php");
   $link=Conectarse();
   $Sql="select * from animes where id LIKE '%".$_POST['id']."%'";
   $result=mysql_query($Sql,$link);
?>
<table border="1" cellspacing="1" cellpadding="1">
<tr>
<td>&nbsp;id</td>
<td>&nbsp;nombre&nbsp;</td>
<td>&nbsp;categoria&nbsp;</td>
<td>&nbsp;agreg&nbsp;</td>
<td>&nbsp;titu&nbsp;</td>
<td>&nbsp;descripccion&nbsp;</td>
<td>&nbsp;imagen&nbsp;</td>
<td>&nbsp;estado&nbsp;</td>
</tr>
<form name="form1" method="post" action="modifica-anime.php">
<?php     
   while($row = mysql_fetch_array($result)) 
   {
printf("<tr><td><INPUT TYPE='text' NAME='id' SIZE='20' MAXLENGTH='30' value='%s'></td><td>&nbsp;<INPUT TYPE='text' NAME='nombre' SIZE='20' MAXLENGTH='30' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='categoria' SIZE='20' MAXLENGTH='30' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='agreg' SIZE='20' MAXLENGTH='30' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='titu' SIZE='20' MAXLENGTH='30' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='descripccion' SIZE='20' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='imagen' SIZE='20' value='%s'>&nbsp;</td><td>&nbsp;<INPUT TYPE='text' NAME='estado' SIZE='20' MAXLENGTH='30' value='%s'>&nbsp;</td></tr>", $row["id"],$row["nombre"],$row["categoria"],$row["agreg"],$row["titu"],$row["descripccion"],$row["imagen"],$row["estado"]);
   }
   mysql_free_result($result);
?>
   <input type="submit" name="accion" value="Guardar">
</form>
</body>
</html>