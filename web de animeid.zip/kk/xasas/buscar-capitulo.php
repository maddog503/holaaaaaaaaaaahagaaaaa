<html>
<link rel="image_src" href="/img/imgfb.jpg">

<link rel="shortcut icon" href="favicon.ico">

<link href="/css/main.css" rel="stylesheet" type="text/css">

<base href="<?php echo $web; ?>">

<link rel="alternate" type="application/rss+xml" title="<?php echo $sitio; ?> RSS Feed" href="/rss.php">

<script type="text/javascript" src="/css/prototaculous.js"></script>

<script type="text/javascript" src="/css/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="/css/jquery.tipsy.js"></script>

<script type="text/javascript" src="/css/jquery.jtruncate.pack.js"></script>

<script type="text/javascript" src="/css/script.js"></script>

<script type="text/javascript"></script>

</head>
<body>
<div id="header"><div id="cb">
<!-- logo --><div id="l" class="c"><a href="/" title="Anime Online - <?php echo $sitio; ?> Online" style="float: left;"><iframe src="cabecera.html" border="0" marginwidth="0" marginheight="-50" height="100" width="280" scrolling="no" border="0" frameborder="0" name="logo"></iframe></a>
</div>
</div></div>

<div id="mm"><div id="eim"></div><div id="m">

<?php include("css/menu-post.php"); ?>

</div><div id="edm"></div></div></div>
<div id="main">
<?php
   include("conec.php");
   $link=Conectarse();
   $Sql="select * from capitulos where id_anime='".$_POST['id_anime']."'";
   $result=mysql_query($Sql,$link);
?>
<table border="1" cellspacing="1" cellpadding="1">
<tr>
<td>&nbsp;id_anime&nbsp;</td>
<td>&nbsp;nombre_capitulo&nbsp;</td>
<td>&nbsp;sub&nbsp;</td>
<td>&nbsp;opcn&nbsp;</td>
<td>&nbsp;embed&nbsp;</td>
<td>&nbsp;url&nbsp;</td>
</tr>
<form name="form1" method="post" action="modifica-capitulo.php">
<?php     
   while($row = mysql_fetch_array($result)) 
   {
printf("<tr>
<td><INPUT TYPE='text' NAME='id_anime' SIZE='6' MAXLENGTH='30' value='%s'></td>
<td>&nbsp;<INPUT TYPE='text' NAME='nombre_capitulo' SIZE='10' MAXLENGTH='30' value='%s'>&nbsp;</td>
<td>&nbsp;<INPUT TYPE='text' NAME='sub' SIZE='9' MAXLENGTH='30' value='%s' disabled='disabled'>&nbsp;</td>
<td>&nbsp;<INPUT TYPE='text' NAME='opcn' SIZE='10' value='%s' disabled='disabled'>&nbsp;</td>
<td>&nbsp;<textarea name='embed' cols='45' row='19'>%s</textarea>&nbsp;</td>
<td>&nbsp;<textarea name='url' cols='40' row='19'>%s</textarea>&nbsp;</td>
</tr>", $row["id_anime"],$row["nombre_capitulo"],$row["sub"],$row["opcn"],$row["embed"],$row["url"]);
   }
   mysql_free_result($result);
?>
   <input type="submit" name="accion" value="Guardar">
</form>
</body>
</html>