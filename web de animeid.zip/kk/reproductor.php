<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>radio anime</title>
<script src="reproductor1.php_files/swfobject.js" language="javascript"></script>
<style>
*{
	margin:0px;
	padding:0px;
	
}
body{
	background-color: transparent;
}
#cuerpo{
	text-align:center;
	margin:0px auto;
	width:200px;
	height:150px;
	background:url(images/default.png);
}
#fondo{
	margin:0px;
	width:200px;
	height:150px;
	background:url(http://img3.xooimage.com/files/0/1/5/logo-1f760cd.png);
}
.link{
	width:100%;
	border:0px;
	display:block;
	height:105px;
}
#player{
	display:block;
	height:20px;
}
a:link, a:visited{
	font-family:"Palatino Linotype", "Book Antiqua", Palatino, serif;
	color:#FFF;
	text-decoration:none;
	margin-top:0px;
	font-size:12px;
	font-weight:bold;
	text-shadow:#000 1px 1px 1px;
}
a:hover{
	color:#000;
	text-shadow:#FFF 1px 1px 1px;
}
</style>

</head><body>

<div id="cuerpo">
    <div id="fondo">
        <a href="http://anime-radio.net/" target="_top"><div class="link"></div></a>
    <embed src="http://50.7.243.50:8106/" type="application/x-mplayer2" 
width="147" height="25" autostart="1" align="center" border="0"
transparentatstart="1" animationatstart="1" showcontrols="true" 
showaudiocontrols="1" showpositioncontrols="0" showtracker="0"
autosize="1" showstatusbar="0" displaysize="false" />
</embed>  
<a href="www.anime-radio.net/" target="_top">By.ZeriaM</a>
    </div>
</div>
