<?php
require"Configurar.php";
// Core de funciones por Stein

// Hacer url para seo
function hacer_url($cadena){
if (empty($cadena)) return false;
//limpiamos todos los caracteres invalidos
$nueva_cadena = ereg_replace("[^ A-Za-z0-9_-]", "", $cadena);
$nueva_cadena = str_replace(" ","-",$nueva_cadena);
$nueva_cadena = str_replace("%20","-",$nueva_cadena);
$nueva_cadena = str_replace("--","-",$nueva_cadena);
return $nueva_cadena;
}

// Redirecionar al index
function redireccionar(){
header("Location: ".$_web);
}

// validad anime, extraer datos
function anime_v($_id=0){
$ex = @mysql_query("SELECT id,nombre,catg,agreg,titu,categoria,descripccion,imagen,estado,proximo_c,id_capitulo,nombre_capitulo FROM animes INNER JOIN capitulos ON animes.id=capitulos.id_anime where id = ".$_id);
if(@mysql_num_rows($ex) > 0){
while ($i = @mysql_fetch_assoc($ex)){
$anime[] = array("anime"=>'si',
"id"=>$i['id'],"nom"=>$i['nombre'],"descrip"=>$i['descripccion'],"catg"=>$i['catg'],"agreg"=>$i['agreg'],"titu"=>$i['titu'],"categoria"=>$i['categoria'],"id_cap"=>$i['id_capitulo'],"img"=>$i['imagen'],"estado"=>$i['estado'],"prox"=>$i['proximo_c'],"nom_capitulo"=>$i['nombre_capitulo']);
}
}else{
$anime[] = array("anime"=>'no');
}
@mysql_free_result($ex);
return $anime;
}

// validad anime, extraer datos
function embedhentai_v($_id=0){
$ex = @mysql_query("SELECT id,nombre,catg,agreg,titu,categoria,descripccion,imagen,estado,proximo_c,id_capitulo,nombre_capitulo FROM animes INNER JOIN capitulos ON animes.id=capitulos.id_anime where id = ".$_id);
if(@mysql_num_rows($ex) > 0){
while ($i = @mysql_fetch_assoc($ex)){
$anime[] = array("anime"=>'si',
"id"=>$i['id'],"nom"=>$i['nombre'],"descrip"=>$i['descripccion'],"catg"=>$i['catg'],"agreg"=>$i['agreg'],"titu"=>$i['titu'],"categoria"=>$i['categoria'],"id_cap"=>$i['id_capitulo'],"img"=>$i['imagen'],"estado"=>$i['estado'],"prox"=>$i['proximo_c'],"nom_capitulo"=>$i['nombre_capitulo']);
}
}else{
$anime[] = array("anime"=>'no');
}
@mysql_free_result($ex);
return $anime;
}

// funcion para episodios animes
function ver_v($_id=0){
$ex = @mysql_query("SELECT id,nombre,imagen,sub,descripccion,id_capitulo,nombre_capitulo,opcn,embed,url FROM animes INNER JOIN capitulos ON animes.id=capitulos.id_anime where id_capitulo =".$_id);
if(@mysql_num_rows($ex) > 0){
while ($i = @mysql_fetch_assoc($ex)){
$anime[] = array("CAPITULO"=>'si',
"id"=>$i['id'],"nom"=>$i['nombre'],"img"=>$i['imagen'],"sub"=>$i['sub'],"descrip"=>$i['descripccion'],"id_cap"=>$i['id_capitulo'],"nom_capitulo"=>$i['nombre_capitulo'],"opcn"=>$i['opcn'],"embed"=>$i['embed'],"url"=>$i['url'],"id_cap"=>$i['id_capitulo']);
}
}else{
$anime[] = array("CAPITULO"=>'no');
}
@mysql_free_result($ex);
return $anime;
}

// funcion para embed episodios
function embed_v($_id=0){
$ex = @mysql_query("SELECT id,nombre,imagen,sub,descripccion,id_capitulo,nombre_capitulo,opcn,embed,url FROM animes INNER JOIN capitulos ON animes.id=capitulos.id_anime where id_capitulo =".$_id);
if(@mysql_num_rows($ex) > 0){
while ($i = @mysql_fetch_assoc($ex)){
$anime[] = array("CAPITULO"=>'si',
"id"=>$i['id'],"nom"=>$i['nombre'],"img"=>$i['imagen'],"sub"=>$i['sub'],"descrip"=>$i['descripccion'],"id_cap"=>$i['id_capitulo'],"nom_capitulo"=>$i['nombre_capitulo'],"opcn"=>$i['opcn'],"embed"=>$i['embed'],"url"=>$i['url'],"id_cap"=>$i['id_capitulo']);
}
}else{
$anime[] = array("CAPITULO"=>'no');
}
@mysql_free_result($ex);
return $anime;
}

function cortarTexto($texto) {
    $tamano = 22; // tamaño maximo
    $textoFinal = ''; // Resultado
    if (strlen($texto) < $tamano) $tamano = strlen($texto);
    for ($i=0; $i <= $tamano - 1; $i++) {
        $textoFinal .= $texto[$i];
    }
if(strlen($texto)<25){ return $texto;}else{return $textoFinal."...";}
}

function cortarTex($tex) {
    $tamano = 100; // tamaño maximo
    $texFinal = ''; // Resultado
    if (strlen($tex) < $tamano) $tamano = strlen($tex);
    for ($i=0; $i <= $tamano - 1; $i++) {
        $texFinal .= $tex[$i];
    }
if(strlen($tex)<100){ return $tex;}else{return $texFinal."...";}
}

// funcion para index menus
function index_0_z(){
$x=@mysql_query("SELECT nombre,catg,id,categoria FROM animes WHERE SUBSTRING(nombre,1,1) IN ('.', '0','1','2','3','4','5','6','7','8','9', 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z') order by nombre asc");
while($i=@mysql_fetch_array($x)){
echo "<li><a alt=\"".$i['categoria']." Online ".$i['nombre']."\" title=\"".$i['categoria']." Online ".$i['nombre']."\" href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\"><span>".cortarTexto($i['nombre'])."</span></a></li>";
}
@mysql_free_result($x);
}


function index_anime(){
$x=@mysql_query("SELECT nombre,catg,id,imagen,descripccion,agreg,categoria FROM animes WHERE SUBSTRING(catg,1,9) IN ('Anime') ORDER BY id DESC limit 0,21");
while($i=mysql_fetch_array($x)){
echo "<div class=\"bl\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\"><img src=\"".$i['imagen']."\" class=\"im\" width=\"166\" border=\"0\" height=\"250\"></a><div class=\"tt\"><h1><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\">".cortarTexto($i['nombre'])."</a></h1></div></div>";
}
@mysql_free_result($x);
}


function index_ova(){
$x=@mysql_query("SELECT nombre,catg,id,imagen,descripccion,agreg,categoria FROM animes WHERE SUBSTRING(catg,1,8) IN ('ova') ORDER BY id DESC limit 0,8");
while($i=mysql_fetch_array($x)){
echo "<div class=\"a\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\"><img src=\"".$i['imagen']."\" alt=\"".$i['nombre']."\" width=\"49\" height=\"71\" border=\"0\"></a><div class=\"at\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\">".cortarTexto($i['nombre'])."</a></div><div class=\"at\" style=\"margin-top:0px\"><span>Publicado: ".$i['agreg']."</span></div><div class=\"ad\">".cortarTex($i['descripccion'])."</div></div>";
}
@mysql_free_result($x);
}


function index_peli(){
$x=@mysql_query("SELECT nombre,catg,id,imagen,descripccion,agreg,categoria FROM animes WHERE SUBSTRING(catg,1,8) IN ('pelicula') ORDER BY id DESC limit 0,8");
while($i=mysql_fetch_array($x)){
echo "<div class=\"a\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\"><img src=\"".$i['imagen']."\" alt=\"".$i['nombre']."\" width=\"49\" height=\"71\" border=\"0\"></a><div class=\"at\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\">".cortarTexto($i['nombre'])."</a></div><div class=\"at\" style=\"margin-top:0px\"><span>Publicado: ".$i['agreg']."</span></div><div class=\"ad\">".cortarTex($i['descripccion'])."</div></div>";
}
@mysql_free_result($x);
}

function index_ani(){
$x=@mysql_query("SELECT id,nombre,descripccion,catg,agreg,categoria,imagen from `capitulos` limit 7,10");
while($i=mysql_fetch_array($x)){
echo "<div class=\"a\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\"><img src=\"".$i['imagen']."\" alt=\"".$i['nombre']."\" width=\"49\" height=\"71\" border=\"0\"></a><div class=\"at\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\">".cortarTexto($i['nombre'])."</a></div><div class=\"at\" style=\"margin-top:0px\"><span>Publicado: ".$i['agreg']."</span></div><div class=\"ad\">".cortarTex($i['descripccion'])."</div></div>";
}
@mysql_free_result($x);
}

function elimina_acentos($cadena){
$tofind = "ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ";
$replac = "AAAAAAaaaaaaOOOOOOooooooEEEEeeeeCcIIIIiiiiUUUUuuuuyNn";
return(strtr($cadena,$tofind,$replac));
}

function letra_anime($en){
if($en=="1"){
$c=@mysql_query("select id,nombre,catg,imagen,categoria from animes where nombre rlike '^[0-9]'");
}else{
$c=@mysql_query("select id,nombre,catg,imagen,categoria from animes where SUBSTRING(nombre,1,1) ='".$en."'");
}
while($i=@mysql_fetch_array($c)){
echo "<div class=\"bl\"><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\"><img src=\"".$i['imagen']."\" class=\"im\" width=\"166\" border=\"0\" height=\"250\"></a><div class=\"tt\"><h1><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\">".cortarTexto($i['nombre'])."</a></h1></div></div>";
}
@mysql_free_result($c);
}

function index_anipel(){
/*$ini=rand(0,200);
$fin=$ini+3*/
$c=@mysql_query("select id,nombre,catg,imagen,categoria from animes ORDER BY id DESC limit 0,9");
while($i=@mysql_fetch_array($c)){
echo "<ul><li><a href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\" title=\"".$i['categoria']." Online ".$i['nombre']."\" class=\"".$i['catg']."\">".cortarTexto($i['nombre'])."</a></li></ul>";
}
@mysql_free_result($c);
}

function index_cat(){
$x=@mysql_query("SELECT id, cat FROM categoria");
while($i=@mysql_fetch_array($x)){
echo "<li><a alt=\"".$i['cat']." Online ".$i['nombre']."\" title=\"".$i['categoria']." Online ".$i['nombre']."\" href=\"".$i['catg']."/".hacer_url($i['nombre'])."/".$i['id'].".html\"></a></li>";
}
@mysql_free_result($x);
}


function limpiar_busqueda($q){
$q=str_replace(" ","+",$q);
$q=str_replace("_",'+',$q);
$q=str_replace("-",'+',$q);
$q = htmlspecialchars($q);
$q = str_replace("%","",$q);
$q = str_replace("-"," ",$q);
$q = str_replace("ñ", "n",$q);
$q = str_replace("Ñ", "N",$q);
$q = str_replace("+"," ",$q);
$q = str_replace("<","",$q);
$q = str_replace(">","",$q);
$q = str_replace("&lt;","",$q);
$q = str_replace("&gt;","",$q);
return $q;
}
?>