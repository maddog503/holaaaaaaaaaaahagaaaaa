<?php /* Smarty version 2.6.26, created on 2011-11-29 12:05:28
         compiled from modules/admin/home.tpl */ ?>
<iframe src="http://www.marcofbb.com.ar/movie-script.html" scrolling="no" frameborder="0" marginheight="0px" height="500" width="700"></iframe>