<?php /* Smarty version 2.6.26, created on 2011-11-29 12:20:15
         compiled from modules/admin/videoStream.tpl */ ?>
Creado por <a href="http://dedydamy.com/">dedydamy</a> || Donaciones paypal: dedydamy2@hotmail.com ||
<br />
<iframe src="<?php echo $this->_tpl_vars['msConfig']['datos']['w_url']; ?>
/stream" scrolling="auto" frameborder="0" marginheight="0px" height="800" width="700"></iframe>