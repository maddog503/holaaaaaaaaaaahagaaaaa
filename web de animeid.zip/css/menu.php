<ul id="uno">
<li><a href="http://www.animevision.org" class="menu">Inicio</a></li>
<li><a href="http://www.animevision.org/Dj.html" class="menu" target="_blank">RADIO</a></li>
</ul>