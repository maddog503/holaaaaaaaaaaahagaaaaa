<form name='formulario' id='formulario' method='post' action='enviar.php' target='_self' enctype="multipart/form-data"> 
<p>Anime <input type='text' name='Anime' id='Anime'></p> 
<p>Capitulo <input type='text' name='capitulo' id='capitulo'></p>
<p>Problema</p>
<p><textarea name="mensaje" cols="40" rows="4" id="mensaje"></textarea></p>
<p><input type='submit' value='Enviar'></p>
</form>