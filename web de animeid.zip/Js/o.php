<?

echo file_get_contents($_GET[s]);
?>